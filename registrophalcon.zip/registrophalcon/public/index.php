<?php

error_reporting(E_ALL & ~E_NOTICE);


try {
    define('APPLICATION_PATH', dirname(dirname(__FILE__)) . '/application');
    define('PUBLIC_PATH', dirname(__FILE__));
    define('APPLICATION_ENV', getenv('APPLICATION_ENV') ? getenv('APPLICATION_ENV') : 'development');

    require APPLICATION_PATH . '/Bootstrap.php';
    
    $application = new Bootstrap();
    
//    echo "<pre>";
//    var_dump( \Phalcon\Di\FactoryDefault::getDefault());
//    echo "</pre>";
//    exit;
    $debug = new \Phalcon\Debug();
$debug->listen();
    $application->run();
    
} catch (Phalcon\Exception $e) {
    echo $e->getMessage();
} catch (PDOException $e) {
    echo $e->getMessage();
}
