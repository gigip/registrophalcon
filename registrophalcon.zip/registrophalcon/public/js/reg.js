/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function invalidHandler(event, validator) {

    console.log('invalid');
    $.each(validator.errorList, function (index) {
        if (typeof $('#' + validator.errorList[index].element.name).attr('data-rel') !== 'undefined') {
            //console.log($('#'+validator.errorList[index].element.name).attr('data-rel'));
            $($('#' + validator.errorList[index].element.name).attr('data-rel')).switchClass('form-control-success', 'form-control-danger');
        } else {
            //console.log(($('#'+validator.errorList[index].element.name)));
            $($('#' + validator.errorList[index].element.name)).switchClass('form-control-success', 'form-control-danger');
        }
        $('#' + validator.errorList[index].element.name).closest('.form-group').switchClass('has-success', 'has-danger');
        //console.log($('#'+validator.errorList[index].element.name).closest('.form-group'));
        //$("#" + validator.errorList[index].element.name).closest('.form-group').switchClass('has-success', 'has-danger');
//        if (~validator.errorList[index].element.name.indexOf("_id")) {
//            //console.log(element.attr("name"));
//            //error.insertAfter("#lastname");
//           //$('#' + validator.errorList[index].element.id).next('input').addClass('form-control-danger');
//        } 
        //console.log($('#'+$('#'+validator.errorList[index].element.name).attr('data-rel')));

//        $('#' + validator.errorList[index].element.id).addClass('form-control-danger');
        //$("#" + validator.errorList[index].element.id).closest('.form-group').switchClass('has-success' ,'has-danger');
//        console.log('invalid '+ validator.errorList[index].element.id);
//        $("#" + validator.errorList[index].element.id + "_errors").show().html(validator.errorList[index].message);
//        $("#" + validator.errorList[index].element.id + "_container").addClass('has-danger');
    });
}

function successHandler(form, data, textStatus) {
    if (!data.success) {
        $.each(data, function (key, error) {
            validator = $(form).validate();
            errors = {};
            $("#" + error.field + "_errors").show().html(error.message);
            var f = error.field;
            errors[error.field] = error.message
            validator.showErrors(errors);
        });
        invalidHandler(null, validator);
        return null;
    } else {
        return data;
    }
}

function errorHandler(jqXHR, textStatus, errorThrown) {
    $('#submitError').show().children('#submitErrorMessage').html(errorThrown);
}
;

$.validator.setDefaults({
    debug: true,
    errorClass: 'form-control-feedback',
    validClass: "form-control-success",
//    errorContainer: "#errorContainer",
    errorElement: 'label',
    ignore: [],
    errorPlacement: function (error, element) {
        //    element.parent('div').next(".alert").html(error);
//        if (~element.attr("name").indexOf("_id")) {
//            //console.log(element.attr("name"));
//            //error.insertAfter("#lastname");
//            //error.insertAfter(element.next('input'));
//            //element.parent('div').next(".alert").html(error);
//            $('#'+element.attr("name")+'-error').html(error);
//        } else {
//            //error.insertAfter(element);
//        }
        $('#' + element.attr("name") + '-error').html(error);
    },
//    highlight: function (element, errorClass) {
//        $("#" + element.id).closest('.form-group').switchClass('has-success', 'has-danger');
//    },
//    unhighlight: function(element, errorClass, validClass) {
////        if($(element).)
////        $("#" + element.id).closest('.form-group').switchClass('has-danger', 'has-success');
//    },
    invalidHandler: function (event, validator) {
        invalidHandler(event, validator);
    },
    success: function (label, element) {
        $(label).closest('.form-group').switchClass('has-danger', 'has-success');
//        console.log('success');
//        if (typeof $(element).attr('data-rel') !== 'undefined'){
//            //console.log($($(element).attr('data-rel')));
//            $($(element).attr('data-rel')).switchClass('form-control-danger','form-control-success');
//        }
//        else{
//            //console.log(validator.errorList[index].element.name);
//            $(element).switchClass('form-control-danger','form-control-success');
//        }        
//        $('#'+$(element).attr('data-rel')).switchClass('form-control-danger','form-control-success');
    },
    error: function (e) {
        // do nothing, but register this function
        console.log('error');
    },
});

$.datepicker.setDefaults($.datepicker.regional[ "it" ]);

function formatManufacturersResults(data) {
    if (data.loading)
        return data.text;

//if(!data.length)
//    return 'ciao';

    var markup = "<div class='select2-result-repository clearfix'>" +
            "<div class='select2-result-repository__avatar'><img src='/img/manufacturers/" + data.id + ".jpg' /></div>" +
            "<div class='select2-result-repository__meta'>" +
            "<div class='select2-result-repository__title'>" + data.text + "</div>";

    if (data.description) {
        markup += "<div class='select2-result-repository__description'>" + data.description + "</div>";
    }

    markup += "<div class='select2-result-repository__statistics'>" +
//    "<div class='select2-result-repository__forks'><i class='fa fa-flash'></i> " + data.categories + " Forks</div>" +
            "<div class='select2-result-repository__stargazers'><i class='fa fa-star'></i> " + data.categories + "</div>" +
//    "<div class='select2-result-repository__watchers'><i class='fa fa-eye'></i> " + data.watchers_count + " Watchers</div>" +
            "</div>" +
            "</div></div>";

    return markup;
}
