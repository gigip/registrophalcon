<?php

namespace Registro\Models;

class RegManufacturers extends ModelBase
{

    /**
     *
     * @var integer
     */
    protected $manufacturer_id;

    /**
     *
     * @var string
     */
    protected $manufacturer_name;

    /**
     * Method to set the value of field manufacturer_id
     *
     * @param integer $manufacturer_id
     * @return $this
     */
    public function setManufacturerId($manufacturer_id)
    {
        $this->manufacturer_id = $manufacturer_id;

        return $this;
    }

    /**
     * Method to set the value of field manufacturer_name
     *
     * @param string $manufacturer_name
     * @return $this
     */
    public function setManufacturerName($manufacturer_name)
    {
        $this->manufacturer_name = $manufacturer_name;

        return $this;
    }

    /**
     * Returns the value of field manufacturer_id
     *
     * @return integer
     */
    public function getManufacturerId()
    {
        return $this->manufacturer_id;
    }

    /**
     * Returns the value of field manufacturer_name
     *
     * @return string
     */
    public function getManufacturerName()
    {
        return $this->manufacturer_name;
    }

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->hasMany('manufacturer_id', 'Registro\Models\Reg_manufacturers_reg_categories', 'manufacturer_id', array('alias' => 'Reg_manufacturers_reg_categories'));
        $this->hasMany('manufacturer_id', 'Registro\Models\Reg_models', 'model_manufacturer_id', array('alias' => 'Reg_models'));
    }

    public function getSource()
    {
        return 'reg_manufacturers';
    }

    /**
     * Independent Column Mapping.
     * Keys are the real names in the table and the values their names in the application
     *
     * @return array
     */
    public function columnMap()
    {
        return array(
            'manufacturer_id' => 'manufacturer_id', 
            'manufacturer_name' => 'manufacturer_name'
        );
    }

}
