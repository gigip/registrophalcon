<?php

namespace Registro\Models;

class RegModels extends ModelBase
{

    /**
     *
     * @var integer
     */
    protected $model_id;

    /**
     *
     * @var integer
     */
    protected $model_manufacturer_id;

    /**
     *
     * @var string
     */
    protected $model_code;

    /**
     *
     * @var string
     */
    protected $model_fullname;

    /**
     * Method to set the value of field model_id
     *
     * @param integer $model_id
     * @return $this
     */
    public function setModelId($model_id)
    {
        $this->model_id = $model_id;

        return $this;
    }

    /**
     * Method to set the value of field model_manufacturer_id
     *
     * @param integer $model_manufacturer_id
     * @return $this
     */
    public function setModelManufacturerId($model_manufacturer_id)
    {
        $this->model_manufacturer_id = $model_manufacturer_id;

        return $this;
    }

    /**
     * Method to set the value of field model_code
     *
     * @param string $model_code
     * @return $this
     */
    public function setModelCode($model_code)
    {
        $this->model_code = $model_code;

        return $this;
    }

    /**
     * Method to set the value of field model_fullname
     *
     * @param string $model_fullname
     * @return $this
     */
    public function setModelFullname($model_fullname)
    {
        $this->model_fullname = $model_fullname;

        return $this;
    }

    /**
     * Returns the value of field model_id
     *
     * @return integer
     */
    public function getModelId()
    {
        return $this->model_id;
    }

    /**
     * Returns the value of field model_manufacturer_id
     *
     * @return integer
     */
    public function getModelManufacturerId()
    {
        return $this->model_manufacturer_id;
    }

    /**
     * Returns the value of field model_code
     *
     * @return string
     */
    public function getModelCode()
    {
        return $this->model_code;
    }

    /**
     * Returns the value of field model_fullname
     *
     * @return string
     */
    public function getModelFullname()
    {
        return $this->model_fullname;
    }

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->hasMany('model_id', 'Registro\Models\Reg_items', 'item_model_id', array('alias' => 'Reg_items'));
        $this->belongsTo('model_manufacturer_id', 'Registro\Models\Reg_manufacturers', 'manufacturer_id', array('alias' => 'Reg_manufacturers'));
    }

    public function getSource()
    {
        return 'reg_models';
    }

    /**
     * Independent Column Mapping.
     * Keys are the real names in the table and the values their names in the application
     *
     * @return array
     */
    public function columnMap()
    {
        return array(
            'model_id' => 'model_id', 
            'model_manufacturer_id' => 'model_manufacturer_id', 
            'model_code' => 'model_code', 
            'model_fullname' => 'model_fullname'
        );
    }

}
