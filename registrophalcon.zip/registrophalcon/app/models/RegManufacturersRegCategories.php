<?php

namespace Registro\Models;

class RegManufacturersRegCategories extends ModelBase
{

    /**
     *
     * @var integer
     */
    protected $manufacturer_id;

    /**
     *
     * @var integer
     */
    protected $category_id;

    /**
     * Method to set the value of field manufacturer_id
     *
     * @param integer $manufacturer_id
     * @return $this
     */
    public function setManufacturerId($manufacturer_id)
    {
        $this->manufacturer_id = $manufacturer_id;

        return $this;
    }

    /**
     * Method to set the value of field category_id
     *
     * @param integer $category_id
     * @return $this
     */
    public function setCategoryId($category_id)
    {
        $this->category_id = $category_id;

        return $this;
    }

    /**
     * Returns the value of field manufacturer_id
     *
     * @return integer
     */
    public function getManufacturerId()
    {
        return $this->manufacturer_id;
    }

    /**
     * Returns the value of field category_id
     *
     * @return integer
     */
    public function getCategoryId()
    {
        return $this->category_id;
    }

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->belongsTo('category_id', 'Registro\Models\Reg_items_categories', 'category_id', array('alias' => 'Reg_items_categories'));
        $this->belongsTo('manufacturer_id', 'Registro\Models\Reg_manufacturers', 'manufacturer_id', array('alias' => 'Reg_manufacturers'));
    }

    public function getSource()
    {
        return 'reg_manufacturers_reg_categories';
    }

    /**
     * Independent Column Mapping.
     * Keys are the real names in the table and the values their names in the application
     *
     * @return array
     */
    public function columnMap()
    {
        return array(
            'manufacturer_id' => 'manufacturer_id', 
            'category_id' => 'category_id'
        );
    }

}
