<?php

class Users extends \Phalcon\Mvc\Model
{

    /**
     *
     * @var integer
     */
    protected $user_id;

    /**
     *
     * @var string
     */
    protected $user_username;

    /**
     *
     * @var string
     */
    protected $user_email;

    /**
     *
     * @var string
     */
    protected $user_password;

    /**
     *
     * @var string
     */
    protected $user_firstname;

    /**
     *
     * @var string
     */
    protected $user_lastname;

    /**
     *
     * @var integer
     */
    protected $user_group_id;

    /**
     *
     * @var integer
     */
    protected $user_change_password;

    /**
     *
     * @var string
     */
    protected $user_email_code;

    /**
     *
     * @var string
     */
    protected $user_status;

    /**
     *
     * @var string
     */
    protected $user_created;

    /**
     * Method to set the value of field user_id
     *
     * @param integer $user_id
     * @return $this
     */
    public function setUserId($user_id)
    {
        $this->user_id = $user_id;

        return $this;
    }

    /**
     * Method to set the value of field user_username
     *
     * @param string $user_username
     * @return $this
     */
    public function setUserUsername($user_username)
    {
        $this->user_username = $user_username;

        return $this;
    }

    /**
     * Method to set the value of field user_email
     *
     * @param string $user_email
     * @return $this
     */
    public function setUserEmail($user_email)
    {
        $this->user_email = $user_email;

        return $this;
    }

    /**
     * Method to set the value of field user_password
     *
     * @param string $user_password
     * @return $this
     */
    public function setUserPassword($user_password)
    {
        $this->user_password = $user_password;

        return $this;
    }

    /**
     * Method to set the value of field user_firstname
     *
     * @param string $user_firstname
     * @return $this
     */
    public function setUserFirstname($user_firstname)
    {
        $this->user_firstname = $user_firstname;

        return $this;
    }

    /**
     * Method to set the value of field user_lastname
     *
     * @param string $user_lastname
     * @return $this
     */
    public function setUserLastname($user_lastname)
    {
        $this->user_lastname = $user_lastname;

        return $this;
    }

    /**
     * Method to set the value of field user_group_id
     *
     * @param integer $user_group_id
     * @return $this
     */
    public function setUserGroupId($user_group_id)
    {
        $this->user_group_id = $user_group_id;

        return $this;
    }

    /**
     * Method to set the value of field user_change_password
     *
     * @param integer $user_change_password
     * @return $this
     */
    public function setUserChangePassword($user_change_password)
    {
        $this->user_change_password = $user_change_password;

        return $this;
    }

    /**
     * Method to set the value of field user_email_code
     *
     * @param string $user_email_code
     * @return $this
     */
    public function setUserEmailCode($user_email_code)
    {
        $this->user_email_code = $user_email_code;

        return $this;
    }

    /**
     * Method to set the value of field user_status
     *
     * @param string $user_status
     * @return $this
     */
    public function setUserStatus($user_status)
    {
        $this->user_status = $user_status;

        return $this;
    }

    /**
     * Method to set the value of field user_created
     *
     * @param string $user_created
     * @return $this
     */
    public function setUserCreated($user_created)
    {
        $this->user_created = $user_created;

        return $this;
    }

    /**
     * Returns the value of field user_id
     *
     * @return integer
     */
    public function getUserId()
    {
        return $this->user_id;
    }

    /**
     * Returns the value of field user_username
     *
     * @return string
     */
    public function getUserUsername()
    {
        return $this->user_username;
    }

    /**
     * Returns the value of field user_email
     *
     * @return string
     */
    public function getUserEmail()
    {
        return $this->user_email;
    }

    /**
     * Returns the value of field user_password
     *
     * @return string
     */
    public function getUserPassword()
    {
        return $this->user_password;
    }

    /**
     * Returns the value of field user_firstname
     *
     * @return string
     */
    public function getUserFirstname()
    {
        return $this->user_firstname;
    }

    /**
     * Returns the value of field user_lastname
     *
     * @return string
     */
    public function getUserLastname()
    {
        return $this->user_lastname;
    }

    /**
     * Returns the value of field user_group_id
     *
     * @return integer
     */
    public function getUserGroupId()
    {
        return $this->user_group_id;
    }

    /**
     * Returns the value of field user_change_password
     *
     * @return integer
     */
    public function getUserChangePassword()
    {
        return $this->user_change_password;
    }

    /**
     * Returns the value of field user_email_code
     *
     * @return string
     */
    public function getUserEmailCode()
    {
        return $this->user_email_code;
    }

    /**
     * Returns the value of field user_status
     *
     * @return string
     */
    public function getUserStatus()
    {
        return $this->user_status;
    }

    /**
     * Returns the value of field user_created
     *
     * @return string
     */
    public function getUserCreated()
    {
        return $this->user_created;
    }

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->hasMany('user_id', '_events', 'event_created_by', array('alias' => '_events'));
        $this->hasMany('user_id', '_events', 'event_modified_by', array('alias' => '_events'));
        $this->hasMany('user_id', '_items', 'item_created_by', array('alias' => '_items'));
        $this->hasMany('user_id', '_items', 'item_modified_by', array('alias' => '_items'));
        $this->hasMany('user_id', '_sessions', 'session_user_id', array('alias' => '_sessions'));
        $this->belongsTo('user_group_id', '_user_groups', 'group_id', array('alias' => '_user_groups'));
    }

    /**
     * Independent Column Mapping.
     * Keys are the real names in the table and the values their names in the application
     *
     * @return array
     */
    public function columnMap()
    {
        return array(
            'user_id' => 'user_id', 
            'user_username' => 'user_username', 
            'user_email' => 'user_email', 
            'user_password' => 'user_password', 
            'user_firstname' => 'user_firstname', 
            'user_lastname' => 'user_lastname', 
            'user_group_id' => 'user_group_id', 
            'user_change_password' => 'user_change_password', 
            'user_email_code' => 'user_email_code', 
            'user_status' => 'user_status', 
            'user_created' => 'user_created'
        );
    }

}
