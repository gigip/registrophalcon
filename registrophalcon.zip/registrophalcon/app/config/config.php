<?php

use Phalcon\Config;
    define('APPLICATION_PATH', dirname(dirname(__FILE__)));
return new Config(
    [
        // application
        'application' => [
            'controllersDir'     => APPLICATION_PATH . '/controllers/',
            'viewsDir'           => APPLICATION_PATH . '/views/',
            'modelsDir'                => APPLICATION_PATH . '/models/',
            'pluginsDir'               => APPLICATION_PATH . '/plugins/',
            'libraryDir'               => APPLICATION_PATH . '/library/',
            'voltDir'                  => APPLICATION_PATH . '/cache/volt/',
            'logDir'                   => APPLICATION_PATH . '/logs/',
            'utilsDir'                 => APPLICATION_PATH . '/utils/',
            'securityDir'              => APPLICATION_PATH . '/cache/security/',
            'vendorDir'                => APPLICATION_PATH . '/vendor',
            'baseUri'                  => '',
            'appTitle'                 => 'Phalcon Boilerplate',
            'appName'                  => 'phalcon-boilerplate',
            //'baseUri'                  => 'registrophalcon.local',
            'env'                      => $env,
            'debug'                    => '0',
            'securitySalt'             => 'b5hdr6f9t5a6tjhpei9m',
            'pagination'               => array(
                'itemsPerPage'  => 25
            ),
            'hashTokenExpiryHours'     => 4,
            'dateTimeFormat'           => 'M d, Y H:i:s T'
        ],
        'database'    => [
            'adapter'  => 'Mysql',
            'host'     => 'localhost',
            'username' => 'registro',
            'password' => 'registro',
            'dbname'     => 'registro'
        ],

        // routes
        'routes' => [
            // IndexController
            '/' => [
                'params' => [
                    'module'     => 'frontend',
                    'controller' => 'index',
                    'action'     => 'index',
                    ],
                    'name'   => 'index-index',
                ],
//            'errors' => [
//                'params' => [
//                    'namespace' => 'Registro\\Common',
//                    'module'     => 'frontend',
//                    'controller' => 'errors'
//                ],
//            ],
            '/admin' => [
                'params' => [
                    'module'     => 'backend',
                    'controller' => 'index',
                    'action'     => 'index',
                    ],
                    'name'   => 'index-index',
                ]            
        ],
        'publicResources' => [
            'common-errors' => [
                'show404',
                'show500'
            ],
            'frontend-index' => [
                'index'
            ],
            'backend-index' => [
                'index',
            ],            
        ],
        'privateResources' => [
//            'backend-index' => [
//                'index',
//            ],
        ]        
    ]
);
