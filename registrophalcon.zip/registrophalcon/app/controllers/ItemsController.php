<?php

class ItemsController extends \Phalcon\Mvc\Controller
{

    public function indexAction()
    {

    }

}

