<?php
 
use Phalcon\Mvc\Model\Criteria;
use Phalcon\Paginator\Adapter\Model as Paginator;

class ManufacturersController extends ControllerBase
{

    /**
     * Index action
     */
    public function indexAction()
    {
        $this->persistent->parameters = null;
    }

    /**
     * Searches for manufacturers
     */
    public function searchAction()
    {

        $numberPage = 1;
        if ($this->request->isPost()) {
            $query = Criteria::fromInput($this->di, "Manufacturers", $_POST);
            $this->persistent->parameters = $query->getParams();
        } else {
            $numberPage = $this->request->getQuery("page", "int");
        }

        $parameters = $this->persistent->parameters;
        if (!is_array($parameters)) {
            $parameters = array();
        }
        $parameters["order"] = "manufacturer_id";

        $manufacturers = Manufacturers::find($parameters);
        if (count($manufacturers) == 0) {
            $this->flash->notice("The search did not find any manufacturers");

            return $this->dispatcher->forward(array(
                "controller" => "manufacturers",
                "action" => "index"
            ));
        }

        $paginator = new Paginator(array(
            "data" => $manufacturers,
            "limit"=> 10,
            "page" => $numberPage
        ));

        $this->view->page = $paginator->getPaginate();
    }

    /**
     * Displays the creation form
     */
    public function newAction()
    {

    }

    /**
     * Edits a manufacturer
     *
     * @param string $manufacturer_id
     */
    public function editAction($manufacturer_id)
    {

        if (!$this->request->isPost()) {

            $manufacturer = Manufacturers::findFirstBymanufacturer_id($manufacturer_id);
            if (!$manufacturer) {
                $this->flash->error("manufacturer was not found");

                return $this->dispatcher->forward(array(
                    "controller" => "manufacturers",
                    "action" => "index"
                ));
            }

            $this->view->manufacturer_id = $manufacturer->manufacturer_id;

            $this->tag->setDefault("manufacturer_id", $manufacturer->getManufacturerId());
            $this->tag->setDefault("manufacturer_name", $manufacturer->getManufacturerName());
            
        }
    }

    /**
     * Creates a new manufacturer
     */
    public function createAction()
    {

        if (!$this->request->isPost()) {
            return $this->dispatcher->forward(array(
                "controller" => "manufacturers",
                "action" => "index"
            ));
        }

        $manufacturer = new Manufacturers();

        $manufacturer->setManufacturerId($this->request->getPost("manufacturer_id"));
        $manufacturer->setManufacturerName($this->request->getPost("manufacturer_name"));
        

        if (!$manufacturer->save()) {
            foreach ($manufacturer->getMessages() as $message) {
                $this->flash->error($message);
            }

            return $this->dispatcher->forward(array(
                "controller" => "manufacturers",
                "action" => "new"
            ));
        }

        $this->flash->success("manufacturer was created successfully");

        return $this->dispatcher->forward(array(
            "controller" => "manufacturers",
            "action" => "index"
        ));

    }

    /**
     * Saves a manufacturer edited
     *
     */
    public function saveAction()
    {

        if (!$this->request->isPost()) {
            return $this->dispatcher->forward(array(
                "controller" => "manufacturers",
                "action" => "index"
            ));
        }

        $manufacturer_id = $this->request->getPost("manufacturer_id");

        $manufacturer = Manufacturers::findFirstBymanufacturer_id($manufacturer_id);
        if (!$manufacturer) {
            $this->flash->error("manufacturer does not exist " . $manufacturer_id);

            return $this->dispatcher->forward(array(
                "controller" => "manufacturers",
                "action" => "index"
            ));
        }

        $manufacturer->setManufacturerId($this->request->getPost("manufacturer_id"));
        $manufacturer->setManufacturerName($this->request->getPost("manufacturer_name"));
        

        if (!$manufacturer->save()) {

            foreach ($manufacturer->getMessages() as $message) {
                $this->flash->error($message);
            }

            return $this->dispatcher->forward(array(
                "controller" => "manufacturers",
                "action" => "edit",
                "params" => array($manufacturer->manufacturer_id)
            ));
        }

        $this->flash->success("manufacturer was updated successfully");

        return $this->dispatcher->forward(array(
            "controller" => "manufacturers",
            "action" => "index"
        ));

    }

    /**
     * Deletes a manufacturer
     *
     * @param string $manufacturer_id
     */
    public function deleteAction($manufacturer_id)
    {

        $manufacturer = Manufacturers::findFirstBymanufacturer_id($manufacturer_id);
        if (!$manufacturer) {
            $this->flash->error("manufacturer was not found");

            return $this->dispatcher->forward(array(
                "controller" => "manufacturers",
                "action" => "index"
            ));
        }

        if (!$manufacturer->delete()) {

            foreach ($manufacturer->getMessages() as $message) {
                $this->flash->error($message);
            }

            return $this->dispatcher->forward(array(
                "controller" => "manufacturers",
                "action" => "search"
            ));
        }

        $this->flash->success("manufacturer was deleted successfully");

        return $this->dispatcher->forward(array(
            "controller" => "manufacturers",
            "action" => "index"
        ));
    }

}
