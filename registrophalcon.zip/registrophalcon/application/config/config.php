<?php
use Phalcon\Config;
use Phalcon\Logger;

return new Config(
    [
        // application
        'application' => [
            'modulesDir'               => APPLICATION_PATH . '/modules/',
            'commonControllersDir'     => APPLICATION_PATH . '/controllers/',
            'commonViewsDir'           => APPLICATION_PATH . '/modules/common/views/',
            'modelsDir'                => APPLICATION_PATH . '/models/',
            'pluginsDir'               => APPLICATION_PATH . '/plugins/',
            'formsDir'                 => APPLICATION_PATH . '/forms/',
            'libraryDir'               => APPLICATION_PATH . '/library/',
            'voltDir'                  => APPLICATION_PATH . '/cache/volt/',
            'logDir'                   => APPLICATION_PATH . '/logs/',
            'utilsDir'                 => APPLICATION_PATH . '/utils/',
            'securityDir'              => APPLICATION_PATH . '/cache/security/',
            'vendorDir'                => APPLICATION_PATH . '/vendor',
            'baseUri'                  => '',
            'appTitle'                 => 'Registro',
            'appName'                  => 'registro',
            'baseUri'                  => 'http://registrophalcon.local/',
            'env'                      => $env,
            'debug'                    => '1',
            'cryptSalt'             => 'b5hdr6f9t5a6tjhpei9m',
            'pagination'               => array(
                'itemsPerPage'  => 25
            ),
            'hashTokenExpiryHours'     => 4,
            'dateTimeFormat'           => 'M d, Y H:i:s T'
        ],
        'database'    => [
            'adapter'  => 'Mysql',
            'host'     => 'localhost',
            'username' => 'registro',
            'password' => 'registro',
            'dbname'     => 'registro',
        ],
    'logger' => [
        'path'     => APPLICATION_PATH . '/logs/',
        'format'   => '%date% [%type%] %message%',
        'date'     => 'D j H:i:s',
        'logLevel' => Logger::DEBUG,
        'filename' => 'application.log',
    ],
        // routes
        'routes' => [
            // IndexController
            '/' => [
                'params' => [
                    'module'     => 'frontend',
                    'controller' => 'index',
                    'action'     => 'index',
                    ],
                    'name'   => 'frontend-index',
                ],
            'errors' => [
                'params' => [
                    'namespace' => 'Registro\\Common',
                    'module'     => 'frontend',
                    'controller' => 'errors'
                ],
            ],
            '/test' => [
                'params' => [
                    'module'     => 'frontend',
                    'controller' => 'test',
                    'action'     => 'index',
                    ],
                    'name'   => 'frontend-test',
                ],
            '/session' => [
                'params' => [
                    'module'     => 'common',
                    'controller' => 'session',
                    'action'     => 'login'
                    ],
                    'name'       => 'common-session'
            ],
            '/confirm/{code}/{email}' => [
                'params' => [
                    'module'    => 'common',
                    'controller' => 'user_control',
                    'action' => 'confirmEmail'
                ]
            ],
            '/reset-password/{code}/{email}' => [
                'params' => [
                    'module' => 'common',
                    'controller' => 'user_control',
                    'action' => 'resetPassword'
                ]
            ],  
            '/session/:action' => [
                'params' => [
                    'module'     => 'common',
                    'controller' => 'session',
                    'action'     => 1
                ]
            ],      
            '/user-panel' => [
                'params' => [
                    'module'     => 'frontend',
                    'controller' => 'user_panel',
                    'action'     => 'index',
                    ],
                    'name'   => 'frontend-user_panel',
                ],          
            '/items' => [
                'params' => [
                    'module'     => 'frontend',
                    'controller' => 'items',
                    'action'     => 'index',
                    ],
                    'name'   => 'frontend-items',
                ],
            '/items/{step:[1-3]{1}}/{item_id:int}' => [
                'params' => [
                    'module'     => 'frontend',
                    'controller' => 'items',
                    'action'     => 'add',
                    'step'       => 1,
                    'item_id'    => 2,
                    ],
                    'name'   => 'frontend-items',
                ],               
            '/admin' => [
                'params' => [
                    'module'     => 'backend',
                    'controller' => 'index',
                    'action'     => 'index',
                    ],
                    'name'   => 'backend-index',
                ],
            
            '/api/index/{id:([0-9]{1,32})}/:params' => [
                'params' => [
                    'module' => 'api',
                    'controller' => 'index',
                    'action' => 'index',
                    ],
                'name'   => 'index-index',
                ],
            '/api/manufacturers/list/:params' => [
                'params' => [
                    'module' => 'api',
                    'controller' => 'manufacturers',
                    'action' => 'list',
                    ],
                'name'   => 'api-manufacturers',
                ],
            '/api/manufacturers/search/:params' => [
                'params' => [
                    'module' => 'api',
                    'controller' => 'manufacturers',
                    'action' => 'search',
                    ],
                'name'   => 'api-manufacturers',
                ],              
            '/api/manufacturers/add/:params' => [
                'params' => [
                    'module' => 'api',
                    'controller' => 'manufacturers',
                    'action' => 'add',
                    ],
                'name'   => 'api-manufacturers',
                ],
            '/api/models/search/:params' => [
                'params' => [
                    'module' => 'api',
                    'controller' => 'models',
                    'action' => 'search',
                    ],
                'name'   => 'api-models',
                ],
            '/api/models/add/:params' => [
                'params' => [
                    'module' => 'api',
                    'controller' => 'models',
                    'action' => 'add',
                    ],
                'name'   => 'api-models',
                ],
            '/api/items/addReceipt/:params' => [
                'params' => [
                    'module' => 'api',
                    'controller' => 'items',
                    'action' => 'addReceipt',
                    ],
                'name'   => 'api-items',
                ],            
            ],
        'publicResources' => [
            'common-errors' => [
                'show404',
                'show500'
            ],
            'common-session' => [
              'login'  
            ],
            'frontend-index' => [
                'index'
            ],
            'frontend-errors' => [
                'show500'
            ],
            'frontend-test' => [
                'index'
            ],            
            'frontend-items' => [
                'index',
                'add'
            ],
            'frontend-user_panel' => [
                'index'
            ]
        ],
        'privateResources' => [
            'backend-index' => [
                'index',
            ],
            'frontend-user_panel' => [
                'index'
            ],
            'frontend-items' => [
                'add'
            ]
        ]        
    ]
);
