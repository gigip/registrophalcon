<?php

use Phalcon\Mvc\View;
use Phalcon\DI\FactoryDefault;
use Phalcon\Mvc\Dispatcher;
use Phalcon\Mvc\Url as UrlProvider;
use Phalcon\Db\Adapter\Pdo\Mysql;
use Phalcon\Mvc\View\Engine\Volt as VoltEngine;
use Phalcon\Mvc\Model\Metadata\Memory as MetaData;
use Phalcon\Session\Adapter\Files as SessionAdapter;
use Phalcon\Flash\Session as FlashSession;
use Phalcon\Events\Manager as EventsManager;
use Phalcon\Logger\Adapter\File as PhLogFileAdapter;
use Phalcon\Mvc\Application;
use Registro\Flash;
use Registro\Acl;
use Registro\Auth;
use Phalcon\Translate\Adapter\NativeArray;
use Phalcon\Crypt;
use Registro\Mail;
use Phalcon\Logger\Adapter\File as FileLogger;
use Phalcon\Logger\Formatter\Line as FormatterLine;
use Registro\Breadcrumbs;

class Bootstrap extends \Phalcon\DI\FactoryDefault {

    protected $services = array(
        'config',
        'loader',
        'view',
        'translator',
        //'modelmanager',
        'crypt',
        'debug',
        'logger',
        'auth',
        'acl',
        'db',
        'url',
        'dispatcher',
        'router',
        'session',
        'flash',
        'mail',
        'breadcrumbs'
    );

    public function __construct()
    {
        parent::__construct();

        $this->bindServices();
    }

    protected function bindServices()
    {

        $reflection = new \ReflectionObject( $this );
        $methods = $reflection->getMethods();

        foreach( $this->services as $service ){
            $methodName = 'init' . ucfirst( $service );
            $this->$methodName();
        }
    }

    public function run()
    {

        try{


            $application = new Application();
            $application->setDI( $this );

            // Handing missing controller errors
//            $this->set('dispatcher', function() {
//
//                //Create an EventsManager
//                $eventsManager = new EventsManager();
//
//                // Attach a listener
//                $eventsManager->attach("dispatch:beforeException", function($event, $dispatcher, $exception) {
//
//                    // Handle 404 exceptions
//                    if ($exception instanceof DispatchException) {
//                        $dispatcher->forward(array(
//                            'controller' => 'index',
//                            'action' => 'internalServerError'
//                        ));
//                        return false;
//                    }
//
//                    // Alternative way, controller or action doesn't exist
//                    if ($event->getType() == 'beforeException') {
//                        switch ($exception->getCode()) {
//                            case \Phalcon\Dispatcher::EXCEPTION_HANDLER_NOT_FOUND:
//                            case \Phalcon\Dispatcher::EXCEPTION_ACTION_NOT_FOUND:
//                                $dispatcher->forward(array(
//                                    'controller' => 'index',
//                                    'action' => 'internalServerError'
//                                ));
//                                return false;
//                        }
//                    }
//                });
//
//                // Instantiate the Security plugin
//                $security = new SecurityPlugin;
//                
//                // Listen for events produced in the dispatcher using the Security plugin
//                $eventsManager->attach('dispatch', $security);
//
//                $dispatcher = new \Phalcon\Mvc\Dispatcher();
//
//                // Bind the EventsManager to the dispatcher
//                $dispatcher->setEventsManager($eventsManager);
//
//                return $dispatcher;
//
//            }, true);            

            /**
             * Register application modules
             */
            $config = $this->get( 'config' );
            $application->registerModules(
                    [
                        'common' => [
                            'className' => 'Registro\Common\Module',
                            'path' => $config->application->modulesDir . 'common/Module.php'
                        ],
                        'frontend' => [
                            'className' => 'Registro\Frontend\Module',
                            'path' => $config->application->modulesDir . 'frontend/Module.php'
                        ],
                        'backend' => [
                            'className' => 'Registro\Backend\Module',
                            'path' => $config->application->modulesDir . 'backend/Module.php'
                        ],
                        'api' => [
                            'className' => 'Registro\Api\Module',
                            'path' => $config->application->modulesDir . 'api/Module.php'
                        ]
                    ]
            );

            $application->setDefaultModule( 'frontend' );
            echo $application->handle()->getContent();
        } catch(PhException $e){
            echo $e->getMessage();
        } catch(\PDOException $e){
            echo $e->getMessage();
        }
    }

    /**
     * Initializes the config. Reads it from its location and
     * stores it in the Di container for easier access
     *
     * @param array $options
     */
    public function initConfig()
    {
        // Create the new object
        $config = require(APPLICATION_PATH . '/config/config.php');

        $this->setShared( 'config', $config );
    }

    /**
     * Initializes the loader
     *
     * @param array $options
     */
    protected function initLoader( $options = array() )
    {

        $config = $this->get( 'config' );

        // Creates the autoloader
        $loader = new Phalcon\Loader();

        $loader->registerDirs(
                array(
                    $config->application->modelsDir,
                    $config->application->libraryDir,
                    //$config->application->formsDir,
                    $config->application->pluginsDir
                )
        );

        $loader->registerNamespaces(
                [
                    'Registro' => $config->application->libraryDir,
                    'Registro\Models' => $config->application->modelsDir,
                    'Registro\Plugins' => $config->application->pluginsDir,
                    'Registro\Forms' => $config->application->formsDir,
                    'Registro\Common\Controllers' => $config->application->commonControllersDir
                ]
        );

        $loader->register();

        // Dump it in the DI to reuse it
        return $loader;
    }

    /**
     * Initializes the database
     *
     * @param array $options
     */
    protected function initDb()
    {

        $config = $this->get( 'config' );

        // setup database service
        $this->setShared( 'db', function () use ($config){

            $connection = new Mysql(
                    array(
                'host' => $config->database->host,
                'username' => $config->database->username,
                'password' => $config->database->password,
                'dbname' => $config->database->dbname
                    )
            );

            // log sql statements
            if( '1' == $config->application->debug )
            {
                $eventsManager = new EventsManager();

                $logger = new PhLogFileAdapter( $config->application->logDir . '/db.log' );

                //Listen all the database events
                $eventsManager->attach( 'db', function ($event, $connection) use ($logger){
                    if( $event->getType() == 'beforeQuery' )
                    {
                        $sqlVariables = $connection->getSQLVariables();

                        if( count( $sqlVariables ) )
                        {
                            $logger->log( $connection->getSQLStatement() . ' ' . join( ', ', $sqlVariables ), Phalcon\Logger::INFO );
                        }
                        else
                        {
                            $logger->log( $connection->getSQLStatement(), Phalcon\Logger::INFO );
                        }
                    }
                } );

                // Assign the eventsManager to the db adapter instance
                $connection->setEventsManager( $eventsManager );
            }

            return $connection;
        } );
    }

    /**
     * The URL component is used to generate all kind of urls in the application
     */
    protected function initUrl()
    {
        $url = new UrlProvider();

        $url->setBaseUri( $this->get( 'config' )->application->baseUri );
        $this->setShared( 'url', $url );
    }

    /**
     * We register the events manager
     */
    protected function initDispatcher()
    {

        $eventsManager = new EventsManager;

        /**
         * Check if the user is allowed to access certain action using the SecurityPlugin
         */
        $eventsManager->attach( "dispatch:beforeDispatch", new SecurityPlugin );
        /**
         * Handle exceptions and not-found exceptions using NotFoundPlugin
         */
        $eventsManager->attach( 'dispatch:beforeException', new NotFoundPlugin );

        $dispatcher = new Dispatcher;
        $dispatcher->setEventsManager( $eventsManager );
//$dispatcher->setDefaultNamespace("Registro\Frontend\Controllers");

        $this->set( 'dispatcher', $dispatcher );
    }

    protected function initRouter()
    {
        $router = new \Phalcon\Mvc\Router( true );

        // 404
//        $router->notFound(
//            array(
//                'module'     => 'common',
//                "controller" => "errors",
//                "action"     => "show404",
//            )
//        );
        $router->removeExtraSlashes( true );

        foreach( $this->get( 'config' )['routes'] as $route => $items ){
            $router->add( $route, $items->params->toArray() )->setName( $items->name );
        }

        $this->setShared( 'router', $router );
    }

    /**
     * Setting up the view component
     */
    protected function initView()
    {
        $this->set( 'view', function (){
            $config = $this->getConfig();

            $view = new View();

            //$view->setLayoutsDir( $config->application->modulesDir . '/common/layouts/' );
            //$view->setTemplateBefore( 'main' );

            $view->registerEngines( [
                '.volt' => function ($view){
                    $config = $this->getConfig();

                    $volt = new VoltEngine( $view, $this );

                    //$volt->getCompiler()->addFunction('_', 'getTranslator');
                    $volt->setOptions( [
                        'compiledPath' => $config->application->voltDir,
                        'compiledSeparator' => '_',
                        'compileAlways' => true
                    ] );

                    return $volt;
                }
            ] );
            // Create an events manager
            $eventsManager = new EventsManager();

            // Attach a listener for type "view"
            $eventsManager->attach(
                    "view", function (Phalcon\Events\Event $event, $view){
                $this->get( 'logger' )->log( $event->getType(), " - " . $view->getActiveRenderPath() . PHP_EOL );
            }
            );
            // Bind the eventsManager to the view component
            $view->setEventsManager( $eventsManager );
            $view->t = $this->getTranslator();
            return $view;
        }, true );
    }

    /**
     * Initializes the session
     *
     * @param array $options
     */
    protected function initSession( $options = array() )
    {

        $config = $this->get( 'config' );

        //return function () use ($config) {

        $session = new Phalcon\Session\Adapter\Files( array(
            'uniqueId' => $config->application->appName
                ) );

        $session->start();

        $this->setShared( 'session', $session );

        // };
    }

    protected function initAuth()
    {
        $this->setShared( 'auth', new Auth );
    }

    protected function initAcl()
    {
        $acl = new Acl();
        //$acl->addPrivateResources( $this->get( 'config' )->privateResources->toArray() );
        //$acl->getAcl();
        $this->setShared( 'acl', $acl );
    }

    /**
     * Initializes debug
     *
     * @param array $options
     */
    protected function initDebug( $options = array() )
    {

//        $config = $this->di['config'];
        // Create the new object
        $debug = new \Phalcon\Debug();

//        // Store it in the Di container
//        // Settings cones from the include
//        if ('1' == $config->application->debug) {
//        }
        $debug->listen();
        return $debug;
    }

    /**
     * Logger service
     */
    protected function initLogger()
    {

        $this->set( 'logger', function ($filename = null, $format = null){
            $config = $this->getConfig();

            $format = $format ?: $config->get( 'logger' )->format;
            $filename = trim( $filename ?: $config->get( 'logger' )->filename, '\\/' );
            $path = rtrim( $config->get( 'logger' )->path, '\\/' ) . DIRECTORY_SEPARATOR;

            $formatter = new FormatterLine( $format, $config->get( 'logger' )->date );
            $logger = new FileLogger( $path . $filename );

            $logger->setFormatter( $formatter );
            $logger->setLogLevel( $config->get( 'logger' )->logLevel );

            return $logger;
        } );
    }

    /**
     * Flash service with custom CSS classes
     */
    protected function initFlash()
    {
        $this->set( 'flash', function (){
            $flash = new Flash( [
                'error' => 'alert alert-danger',
                'success' => 'alert alert-success',
                'notice' => 'alert alert-info',
                'warning' => 'alert alert-warning'
                    ] );
            $flash->setAutoescape( false );
            $flash->setAutomaticHtml( false );

            return $flash;
        } );
    }

    protected function initTranslator()
    {

        $this->setShared( 'translator', function (){
            require APPLICATION_PATH . '/messages/it.php';

            return new NativeArray( array( 'content' => $messages ) );
        } );
    }

    protected function initModelManager()
    {
        $this->set( 'modelsManager', function () use ($di){
            $eventsManager = new \Phalcon\Events\Manager();
            $eventsManager->attach( 'model', function ($event, $model) use ($di){
                if( 'onValidationFails' === $event->getType() )
                {

                    if( $t = $this->get( 'messages' ) )
                    {
                        foreach( $model->getMessages() as $message ){
                            $message->setMessage( $t->_( $message->getMessage(), $model->toArray() ) );
                        }
                    }
                }
            } );
            $modelsManager = new \Phalcon\Mvc\Model\Manager();
            $modelsManager->setEventsManager( $eventsManager );
            return $modelsManager;
        } );
    }

    /**
     * Crypt service
     */
    protected function initCrypt()
    {
        $this->set( 'crypt', function (){
            $config = $this->getConfig();

            $crypt = new Crypt();
            $crypt->setKey( $config->application->cryptSalt );
            return $crypt;
        } );
    }

    /**
     * Mail service uses AmazonSES
     */
    protected function initMail()
    {
        $this->set( 'mail', function (){
            return new Mail();
        } );
    }

    protected function initBreadcrumbs()
    {
        // Initialize the Breadcrumbs component.
        $this->setShared( 'breadcrumbs', function (){
            $breadcrumbs = new Breadcrumbs;
            $breadcrumbs->setTemplate(
                    '<li class="breadcrumb-item"><a href="{{link}}">{{icon}}{{label}}</a></li>', // linked
                    '<li class="breadcrumb-item active">{{icon}}{{label}}</li>', // not linked
                    ''                    // first icon
            );
            $breadcrumbs->setSeparator( '' );
            return $breadcrumbs;
        } );
    }

}
