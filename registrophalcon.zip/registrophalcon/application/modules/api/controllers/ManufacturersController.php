<?php

namespace Registro\Api\Controller;

use Phalcon\Paginator\Adapter\QueryBuilder;
use Registro\Models\Manufacturer;
use Registro\Forms\ManufacturerForm;
use Phalcon\Mvc\View;

class ManufacturersController extends BaseController {

    public function listAction()
    {
        $limit = $this->getQueryLimit();
        $page = $this->getQueryPage();

        $builder = $this->modelsManager->createBuilder()
                ->from( 'Registro\Models\Manufacturers' )
                ->orderBy( 'manufacturer_name' );

        $paginator = new QueryBuilder( array(
            "builder" => $builder,
            "limit" => $limit,
            "page" => $page
                ) );

        $page = $paginator->getPaginate();
        $data = [ ];

        foreach( $page->items as $manufacturer ){

            $data[] = [
                "manufacturer_id" => $manufacturer->manufacturer_id,
                "manufacturer_name" => $manufacturer->manufacturer_name,
            ];
        }

        $this->response->setJsonContent(
                [
                    "success" => true,
                    "data" => $data
                ]
        );

        return $this->response;
    }

    public function searchAction()
    {

        if( $this->request->isPost() )
        {
            // Check whether the request was made with Ajax
            if( $this->request->isAjax() )
            {
                $phql = 'SELECT * FROM Registro\\Models\\Manufacturer WHERE manufacturer_name LIKE :name:';
                $post_data = $this->request->getJsonRawBody();

//                $manufacturers = $this->modelsManager->executeQuery(
//                        $phql, ["name" => "%" . $post_data->name . "%" ]
//                );

                $data = [ ];

                $manufacturers = Manufacturer::find(    [
        "conditions" => "manufacturer_name LIKE :name:",
        "bind"       => ["name" => "%" . $post_data->name . "%" ]
    ]);
                foreach( $manufacturers as $manufacturer ){
                    foreach( $manufacturer->categories as $category ){
                        $cat .= $category->categories->category_name .', ';
                    }
                    $data[] = [
                        "text" => $manufacturer->manufacturer_name,
                        "id" => $manufacturer->manufacturer_id,
                        "categories" => substr($cat, 0, -2)
                    ];
                }
                $this->response->setJsonContent(
                        $data
//                    "success" => true,
//                    "data" => $data
                );

                return $this->response;
            }
        }
    }

    public function addAction()
    {
        $manufacturer_form = new ManufacturerForm( new Manufacturer );

        if( $this->request->isPost() )
        {
            // Check whether the request was made with Ajax
            if( $this->request->isAjax() )
            {
                $this->data['success'] = false;

                $manufacturer = new Manufacturer( $this->request->getPost() );
                if( $manufacturer->save() )
                {

                    //$this->session->set( 'itemInfo', ['manufacturer' => $manufacturer ] );
                    $this->flash->success( $this->view->t->_( 'success' ) );
                    $this->data['success'] = true;
                    $this->data['manufacturer'] = $manufacturer;
                    
                    $manufacturer_form->setEntity($manufacturer);

                    $manufacturer_form->get( 'manufacturer_name' )->setAttribute( 'disabled', true );
                    $manufacturer_form->remove( 'save' );
                }
                else
                {
                    $this->data['success'] = false;
                    $this->flash->error( $this->view->t->_( 'error' ) );
                    
                    foreach( $manufacturer->getMessages() as $message ){
                        if( $manufacturer_form->has( $message->getField() ) ){
                            $manufacturer_form->getMessagesFor( $message->getField() )
                                    ->appendMessage(
                                            new \Phalcon\Validation\Message(
                                            $this->view->t->_( $message->getMessage(), ["field" => $manufacturer_form->getLabel( $message->getField() ) ] )
                                            )
                            );
                        }
                        else{
                            $this->flash->error( $this->view->t->_( $message->getMessage() ) );
                        }
                    }
//                    foreach( $manufacturer->getMessages() as $message ){
//                        $this->data[] = [
//                            'field' => $message->getField(),
//                            'message' => $this->view->t->_( $message->getMessage(), [ 'field' => $this->t->_( $message->getField() ) ] )
//                        ];
//                    }
                }
            }
        }

        $this->view->manufacturer_form = $manufacturer_form;
        $this->view->render( 'manufacturers', 'add' );
        $this->data['content'] = $this->view->getContent();

        $this->response->setJsonContent(
                $this->data
        );

        return $this->response;
    }

}
