<?php

namespace Registro\Api\Controller;

use Phalcon\Paginator\Adapter\QueryBuilder;
use Registro\Models\Manufacturer;
use Registro\Models\Model;
use Registro\Forms\ModelForm;

class ModelsController extends BaseController {

    public function listAction()
    {
        $limit = $this->getQueryLimit();
        $page = $this->getQueryPage();

        $builder = $this->modelsManager->createBuilder()
                ->from( 'Registro\Models\ItemsModels' )
                ->orderBy( 'manufacturer_name' );

        $paginator = new QueryBuilder( array(
            "builder" => $builder,
            "limit" => $limit,
            "page" => $page
                ) );

        $page = $paginator->getPaginate();
        $data = [ ];

        foreach( $page->items as $manufacturer ){

            $data[] = [
                "manufacturer_id" => $manufacturer->manufacturer_id,
                "manufacturer_name" => $manufacturer->manufacturer_name,
            ];
        }

        $this->response->setJsonContent(
                [
                    "success" => true,
                    "data" => $data
                ]
        );

        return $this->response;
    }

    public function searchAction()
    {

        if( $this->request->isPost() )
        {
            // Check whether the request was made with Ajax
            if( $this->request->isAjax() )
            {
                $phql = 'SELECT * FROM Registro\\Models\\Model WHERE model_manufacturer_id = :manufacturer_id: AND model_fullname LIKE :name:';
                $post_data = $this->request->getJsonRawBody();

                $models = $this->modelsManager->executeQuery(
                        $phql, [
                            "manufacturer_id" => $post_data->manufacturer_id,
                            "name" => "%" . $post_data->name . "%" ]
                );

                $data = [ ];

                foreach( $models as $model ){
                    $data[] = [
                        "text" => $model->model_fullname,
                        "id" => $model->model_id,
                    ];
                }
                $this->response->setJsonContent(
                        $data
                );

                return $this->response;
            }
        }
    }

    public function addAction()
    {
        $model_form = new ModelForm( new Model );

        if( $this->request->isGet())
        {
            parse_str( $this->request->get()['data'], $data );
    
            $manufacturer_id = $data['item_manufacturer_id'];
            if( is_null( $manufacturer_id ) )
            {
                $this->flash->error($this->view->t->_('select_manufacturer'));
                $model_form->get( 'model_manufacturer_name' )->setAttribute('disabled', true);
                $model_form->get( 'model_fullname' )->setAttribute('disabled', true);
                $model_form->remove( 'save' );

            }else{
                    $manufacturer = Manufacturer::findFirst( ['manufacturer_id =' . $manufacturer_id] );
                    $model_form->bind( ['model_manufacturer_id' => $manufacturer->getManufacturerId(),
                                        'model_manufacturer_name' => $manufacturer->getManufacturerName() ], $model_form->getEntity() );

                    $model_form->get( 'model_manufacturer_name' )->setAttribute('disabled', true);        
                // Se la sessione è vuota (l'utente ha selezionato un Costruttore già esiste)
                // oppure arriva un id diverso da quello presente in session, aggiorno la sessione
    //            if (empty($this->session->get( 'itemInfo' )['manufacturer'] ) || ($this->session->get( 'itemInfo' )['manufacturer']->getManufacturerId() != $manufacturer_id ) )
    //            {
    //                $manufacturer = Manufacturer::findFirst( ['manufacturer_id =' . $manufacturer_id] );
    //
    //                $this->session->set('itemInfo', ['manufacturer' => $manufacturer ] );
    //            }
    //            else{
    //                $manufacturer = $this->session->get('itemInfo')['manufacturer'];
    //            }


            }
        }
        elseif( $this->request->isPost() )
            {
                // Check whether the request was made with Ajax
                if( $this->request->isAjax() )
                {
                    $manufacturer_id = $this->request->get('model_manufacturer_id');
                    $manufacturer = Manufacturer::findFirst( ['manufacturer_id =' . $manufacturer_id] );
                    $model_form->bind( ['model_manufacturer_id' => $manufacturer->getManufacturerId(),
                                        'model_manufacturer_name' => $manufacturer->getManufacturerName() ], $model_form->getEntity() );

                    $model_form->get( 'model_manufacturer_name' )->setAttribute('disabled', true);    
            
                    try{
                        $this->data['success'] = false;

                        $model = new Model( $this->request->getPost() );

                        if( $model->save() )
                        {
//                            $itemInfo = $this->session->get('itemInfo');
//                            $itemInfo['model'] = $model;
//                            $this->session->set('itemInfo', $itemInfo);
                            
                            $this->flash->success( $this->view->t->_( 'success' ) );
                            $this->data['success'] = true;
                            $this->data['model'] = $model;
                            
                            $model_form->setEntity($model);

                            $model_form->get( 'model_fullname' )->setAttribute( 'disabled', true );
                            $model_form->remove( 'save' );
                        }
                        else
                        {

                        }

                            $this->data['success'] = false;
                            //$this->flash->error( $this->view->t->_( 'error' ) );

                            foreach( $model->getMessages() as $message ){
                                if( is_string($message->getField()) && $model_form->has( $message->getField()) ){
                                    $model_form->getMessagesFor( $message->getField() )
                                            ->appendMessage(
                                                    new \Phalcon\Validation\Message(
                                                    $this->view->t->_( $message->getMessage(), ["field" => $model_form->getLabel( $message->getField() ) ] )
                                                    )
                                    );
                                }
                                else{
                                    $this->flash->error( $this->view->t->_( $message->getMessage() ) );
                                }
                            }
        //                    foreach( $manufacturer->getMessages() as $message ){
        //                        $this->data[] = [
        //                            'field' => $message->getField(),
        //                            'message' => $this->view->t->_( $message->getMessage(), [ 'field' => $this->t->_( $message->getField() ) ] )
        //                        ];
        //                    }
                            
                    } catch(\Exception $exc){

//                        echo $exc->getTraceAsString();
//                        $this->flash->error( 'ERRORE' );
                    }
                }
            }
        
        $this->view->model_form = $model_form;
        $this->view->render( 'models', 'add' );
        $this->data['content'] = $this->view->getContent();

        $this->response->setJsonContent(
                $this->data
        );

        return $this->response;
    }

}
