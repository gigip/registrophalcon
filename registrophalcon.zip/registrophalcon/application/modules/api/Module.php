<?php

/**
 * @author Patsura Dmitry https://github.com/ovr <talk@dmtry.me>
 */

namespace Registro\Api;

use Phalcon\DiInterface;
use Phalcon\Mvc\Dispatcher;

class Module implements \Phalcon\Mvc\ModuleDefinitionInterface {

    public function registerAutoloaders( DiInterface $dependencyInjector = null )
    {
        $loader = new \Phalcon\Loader();
        $loader->registerNamespaces( array(
            'Registro\Api\Controller' => APPLICATION_PATH . '/modules/api/controllers/',
            'Registro\Api\Model' => APPLICATION_PATH . '/modules/api/models/',
        ) );
        $loader->register();
    }

    public function registerServices( DiInterface $di = null )
    {
        $dispatcher = new Dispatcher();
        $dispatcher->setDI( $di );
        $dispatcher->setDefaultNamespace( 'Registro\Api\Controller' );
        $dispatcher->setDefaultNamespace( 'Registro\Api\Smegma' );
        
//        $dispatcher->setExceptionPath(array(
//            'namespace' => 'Registro\Api\Controller',
//            'module' => 'api',
//            'controller' => 'index',
//            'action'     => 'exception'
//        ));
        $di->set( 'dispatcher', $dispatcher );

        $di->get( 'view' )->setViewsDir( APPLICATION_PATH . '/modules/api/views' );
        $di->get( 'view' )->setPartialsDir( APPLICATION_PATH . '/modules/api/views/partials/' );

        /** @var \Phalcon\Http\ResponseInterface $response */
        $response = $di->get( 'response' );
        $response->setHeader( 'Access-Control-Allow-Origin', '*' )
                ->setContentType( 'application/json', 'utf-8' );
    }

}
