<?php

namespace Registro\Common\Controllers;

use Registro\Models\Users;

/**
 * UserControlController
 * Provides help to users to confirm their passwords or reset them
 */
class UserControlController extends ControllerBase {

    public function indexAction()
    {
        
    }

    /**
     * Confirms an e-mail, if the user must change thier password then changes it
     */
    public function confirmEmailAction()
    {
        try{

            $code = $this->dispatcher->getParam( 'code' );
            $email = $this->dispatcher->getParam( 'email' );

            $user = Users::findFirst( [
                        "user_email_code = ?1 AND user_email = ?2",
                        "bind" => [
                            1 => $code,
                            2 => $email,
                        ],
            ] );

            if( !$user )
            {
                return $this->dispatcher->forward( [
                            'controller' => 'index',
                            'action' => 'index'
                ] );
            }

            if( $user->getUserStatus() != Users::PENDING )
            {
                return $this->dispatcher->forward( [
                            'controller' => 'session',
                            'action' => 'login'
                ] );
            }

            $user->setUserStatus(Users::ACTIVE);

            /**
             * Change the confirmation to 'confirmed' and update the user to 'active'
             */
            if( !$user->save() )
            {

                foreach( $user->getMessages() as $message ){
                    $this->flash->error( $message );
                }

                return $this->dispatcher->forward( [
                            'controller' => 'index',
                            'action' => 'index'
                ] );
            }

            /**
             * Identify the user in the application
             */
            $this->auth->authUserById( $user->getUserId() );

            /**
             * Check if the user must change his/her password
             */
            if( $confirmation->user->mustChangePassword == 'Y' )
            {

                $this->flash->success( 'The email was successfully confirmed. Now you must change your password' );

                return $this->dispatcher->forward( [
                            'controller' => 'users',
                            'action' => 'changePassword'
                ] );
            }

            $this->flash->success( 'The email was successfully confirmed' );

            return $this->dispatcher->forward( [
                        'namespace' => 'Registro\Frontend\Controllers',
                        'module' => 'frontend',
                        'controller' => 'index',
                        'action' => 'index'
            ] );
        } catch(\Registro\Exception $e){
            $this->flash->error( $this->view->t->_( $e->getMessage() ) );
        }
    }

    public function resetPasswordAction()
    {
        $code = $this->dispatcher->getParam( 'code' );

        $resetPassword = ResetPasswords::findFirstByCode( $code );

        if( !$resetPassword )
        {
            return $this->dispatcher->forward( [
                        'controller' => 'index',
                        'action' => 'index'
            ] );
        }

        if( $resetPassword->reset != 'N' )
        {
            return $this->dispatcher->forward( [
                        'controller' => 'session',
                        'action' => 'login'
            ] );
        }

        $resetPassword->reset = 'Y';

        /**
         * Change the confirmation to 'reset'
         */
        if( !$resetPassword->save() )
        {

            foreach( $resetPassword->getMessages() as $message ){
                $this->flash->error( $message );
            }

            return $this->dispatcher->forward( [
                        'controller' => 'index',
                        'action' => 'index'
            ] );
        }

        /**
         * Identify the user in the application
         */
        $this->auth->authUserById( $resetPassword->usersId );

        $this->flash->success( 'Please reset your password' );

        return $this->dispatcher->forward( [
                    'controller' => 'users',
                    'action' => 'changePassword'
        ] );
    }

}
