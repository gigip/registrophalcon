<?php
namespace Registro\Common\Controllers;

use Phalcon\Mvc\Controller;
use Phalcon\Mvc\Dispatcher;
use Phalcon\Translate\Adapter\NativeArray;

class ControllerBase extends Controller
{

//    public function beforeExecuteRoute(Dispatcher $dispatcher)
//    {
//        
//    }
    
    protected function initialize()
    {
//        echo "<pre>";
//        var_dump('asdadads');
//        echo "</pre>";
//        exit;
        $this->tag->prependTitle($this->config->application['appTitle'] .' | ');
        
        $this->view->t = $this->di->get('translator');
        
        // default page title icon
        $this->view->pageTitleIcon = '<i class="fa-fw fa fa-home"></i>';
        $this->view->setLayout('index');
        $this->breadcrumbs->add('crumb-home', '/');
        $this->view->logged_user = $this->di->get('auth')->getIdentity();
    }
    
    /**
     * Execute before the router so we can determine if this is a private controller, and must be authenticated, or a
     * public controller that is open to all.
     *
     * @param Dispatcher $dispatcher
     * @return boolean
     */
//    public function beforeExecuteRoute(Dispatcher $dispatcher)
//    {
//        // Take the active controller/action from the dispatcher
//        $module = $dispatcher->getModuleName();
//        $controller = $dispatcher->getControllerName();
//        $action = $dispatcher->getActionName();
//        echo "<pre>";
//        var_dump($this->acl->getAcl()->isPrivate($module .'-'. $controller));
//        echo "</pre>";
//        exit;
////        echo "<pre>";
////        var_dump($this->acl->isAllowed('Admin', $this->di->get('router')->getMatchedRoute()->getName(), $action, ['a' => $this->auth->getIdentity()->getUserStatus()]));
////        var_dump($this->di->get('router')->getMatchedRoute()->getName());
////        var_dump($this->auth->getIdentity()->getUserStatus());
////        echo "</pre>";
////        exit;
//        // Only check permissions on private controllers
//        if ($this->acl->isPrivate($module .'-'. $controller)) {
//
//            // Get the current identity
//            $identity = $this->auth->getIdentity();
//
//            // If there is no identity available the user is redirected to index/index
//            if (  is_null($identity)) {
//
//                $this->flash->notice('You don\'t have access to this module: private');
//                $this->view->setViewsDir( $this->config->application->modulesDir . '/common/views/' );
//                $dispatcher->forward([
//                    'namespace' => 'Registro\Common\Controllers',
//                    'module' => 'common',
//                    'controller' => 'session',
//                    'action' => 'login'
//                ]);
//                return false;
//            }
////            echo "<pre>";
////            var_dump($identity->userGRoup);
////            echo "</pre>";
////            exit;
//            // Check if the user have permission to the current option
//            if (!$this->acl->isAllowed($identity->userGroup->groupName, $controller, $action)) {
//
//                $this->flash->notice('You don\'t have access to this module: ' . $module .'-'. $controller . ':' . $action);
//
//                if ($this->acl->isAllowed($identity['profile'], $controller, 'index')) {
//                    $dispatcher->forward([
//                        'controller' => $controller,
//                        'action' => 'index'
//                    ]);
//                } else {
////                    $dispatcher->forward([
////                        'controller' => 'user_control',
////                        'action' => 'index'
////                    ]);
//                    $dispatcher->forward([
//                        'namespace' => 'Registro\Common\Controllers',
//                        'module'     => 'common',
//                        'controller' => 'errors',
//                        'action' => 'show401'
//                    ]);
//                }
//
//                return false;
//            }
//        }
//    }
}
