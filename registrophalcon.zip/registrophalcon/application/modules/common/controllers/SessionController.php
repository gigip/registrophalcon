<?php

namespace Registro\Common\Controllers;

use Registro\Forms\LoginForm;
use Registro\Forms\SignUpForm;
use Registro\Forms\ForgotPasswordForm;
use Registro\Models\Users;
use Registro\Models\ResetPasswords;
use Registro\Exception;
use Registro\Common\Controllers\ControllerBase;

/**
 * Controller used handle non-authenticated session actions like login/logout, user signup, and forgotten passwords
 */
class SessionController extends ControllerBase {
    public function initialize()
    {
        $this->tag->setTitle('Sign Up/Sign In');
        parent::initialize();
    }
    public function indexAction()
    {
        
    }

    /**
     * Allow a user to signup to the system
     */
    public function signupAction()
    {
        $user = new Users();
        $form = new SignUpForm( $user );

        if( $this->request->isPost() )
        {
//            if( $this->security->checkToken() )
//            {
            if( $form->isValid( $this->request->getPost() ) != false )
            {

                $user = new Users();
                $user->setUserUsername( $this->request->getPost( 'user_username' ) );
                $user->setUserFirstname( $this->request->getPost( 'user_firstname' ) );
                $user->setUserLastname( $this->request->getPost( 'user_lastname' ) );
                $user->setUserEmail( $this->request->getPost( 'user_email' ) );
                $user->setUserPassword( $this->request->getPost( 'user_password' ) );
                $user->setUserGroupId( 2 );
                // Generate a random confirmation code
                $user->setUserEmailCode( preplace( '/[^a-zA-Z0-9]/', '', base64_encode( openssl_random_pseudo_bytes( 24 ) ) ) );

                if( $user->save() )
                {
                    $this->flash->success( "UItente registrato" );
                    return $this->response->redirect( 'index' );
                }

                foreach( $user->getMessages() as $message ){

                    if( $form->has( $message->getField() ))
                    {
                        $form->getMessagesFor( $message->getField() )
                            ->appendMessage(
                                    new \Phalcon\Validation\Message(
                                    $this->view->t->_( $message->getMessage(), ["field" => $form->getLabel( $message->getField() ) ] )
                                    )
                            );
                    }
                    else{
                        $this->flash->error( $this->view->t->_( $message->getMessage() ) );
                    }
                }
            }
//            }
//            else
//            {
//                $this->flash->error( "token error" );
//            }
        }
        $this->view->form = $form;
    }

    /**
     * Starts a session in the admin backend
     */
    public function loginAction()
    {
        $form = new LoginForm();

        try{

            if( !$this->request->isPost() )
            {

//                if( $this->auth->hasRememberMe() )
//                {
//                    return $this->auth->loginWithRememberMe();
//                }
            }
            else
            {

                if( $form->isValid( $this->request->getPost() ) !== false )
                {
                    $this->auth->check( [
                        'user_email' => $this->request->getPost( 'user_email' ),
                        'user_password' => $this->request->getPost( 'user_password' ),
                        'remember' => $this->request->getPost( 'remember' )
                    ] );

                    return $this->response->redirect( 'index' );
                }
            }
        } catch(RegException $e){
            $this->flash->error( $this->view->t->_( $e->getMessage() ) );
        }

        $this->view->form = $form;
    }

    /**
     * Shows the forgot password form
     */
    public function forgotPasswordAction()
    {
        $form = new ForgotPasswordForm();

        if( $this->request->isPost() )
        {
            if( $form->isValid( $this->request->getPost() ) !== false )
            {

                $user = Users::findFirstByUserEmail( $this->request->getPost( 'user_email' ) );
                if( !$user )
                {
                    $this->flash->warning( 'There is no account associated to this email' );
                }
                else
                {

                    $resetPassword = new ResetPasswords();
                    $resetPassword->usersId = $user->id;
                    if( $resetPassword->save() )
                    {
                        $this->flash->success( 'Success! Please check your messages for an email reset password' );
                    }
                    else
                    {
                        foreach( $resetPassword->getMessages() as $message ){
                            $this->flash->error( $message );
                        }
                    }
                }
            }
        }

        $this->view->form = $form;
    }

    /**
     * Closes the session
     */
    public function logoutAction()
    {
        $this->auth->remove();

        return $this->response->redirect( 'index' );
    }

}
