<?php
namespace Registro\Common\Controllers;
class ErrorsController extends ControllerBase
{
    public function initialize()
    {
        $this->tag->setTitle('Oops!');
        parent::initialize();

        //$this->view->setTemplateBefore('index');

        $this->view->setViewsDir($this->di->get('config')->application->commonViewsDir);
    }

    public function show404Action()
    {
//        echo "<pre>";
//        var_dump($this->di->get('dispatcher')->wasForwarded());
//        echo "</pre>";
//        exit;
    }

    public function show401Action()
    {

    }

    public function show500Action()
    {

    }
}
