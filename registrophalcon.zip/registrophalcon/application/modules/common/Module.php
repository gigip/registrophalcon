<?php

namespace Registro\Common;

use Phalcon\Loader;
use Phalcon\Mvc\View;
use Phalcon\DiInterface;
use Phalcon\Mvc\ModuleDefinitionInterface;

class Module implements ModuleDefinitionInterface
{
    /**
     * Registers the module auto-loader
     *
     * @param DiInterface $di
     */
    public function registerAutoloaders(DiInterface $di = null)
    {
        $loader = new Loader();
        $config = $di->get( 'config' );
        $loader->registerNamespaces(
            [
                'Registro\Frontend\Controllers' => $config->application->modulesDir . '/frontend/controllers/',
                'Registro\Common\Controllers' => $config->application->modulesDir . '/common/controllers/',
                'Registro\Plugins' => '/var/www/registrophalcon/apps/plugins/'
            ]
        );

        $loader->register();
    }

    /**
     * Registers services related to the module
     *
     * @param DiInterface $di
     */
    public function registerServices(DiInterface $di)
    {
        /**
         * Read configuration
         */
        //$config = require __DIR__ . "/config/config.php";

        $di->get('dispatcher')->setDefaultNamespace('Registro\Common\Controllers');
//        $di['dispatcher'] = function () {
//            $dispatcher = new Dispatcher();
//            $dispatcher->setDefaultNamespace('Registro\Frontend\Controllers');
//            return $dispatcher;
//        };

        /**
         * @var $view \Phalcon\Mvc\View
         */
        $view = $di->get( 'view' );
        $config = $di->get( 'config' );
        // $view->setLayout('index');
        $view->setViewsDir( $config->application->modulesDir . '/common/views/' );
        $view->setLayoutsDir( $config->application->modulesDir . '/common/layouts/' );
        $view->setPartialsDir( $config->application->modulesDir . '/common/partials/' );

        $di->set( 'view', $view );

    }
}
