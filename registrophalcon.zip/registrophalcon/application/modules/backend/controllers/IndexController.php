<?php
namespace Registro\Backend\Controllers;
use Registro\Common\Controllers\ControllerBase;

class IndexController extends ControllerBase
{
    public function indexAction()
    {
//    echo "<pre>";
//    var_dump( $this->di);
//    echo "</pre>";
//    exit;
    }

}