<?php

namespace Registro\Backend\Controllers;

class AdminController extends ControllerBase
{

    public function indexAction()
    {
    }
}
