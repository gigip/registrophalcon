<?php

namespace Registro\Backend;

use Phalcon\Loader;
use Phalcon\Mvc\View;
use Phalcon\DiInterface;
use Phalcon\Mvc\Dispatcher;
use Phalcon\Mvc\ModuleDefinitionInterface;
use Phalcon\Db\Adapter\Pdo\Mysql as MySQLAdapter;

class Module implements ModuleDefinitionInterface
{
    /**
     * Registers the module auto-loader
     *
     * @param DiInterface $di
     */
    public function registerAutoloaders(DiInterface $di = null)
    {
        $loader = new Loader();
        $config = $di->get( 'config' );
        $loader->registerNamespaces(
            [
                'Registro\Common\Controllers' => $config->application->modulesDir . '/common/controllers/',
                    'Registro\Backend\Controllers' => $config->application->modulesDir . '/backend/controllers/',
                    'Registro\Backend\Models' => $config->application->modulesDir . '/models/',
                    'Registro\Plugins' => '/var/www/registrophalcon/apps/plugins/'
            ]
        );

        $loader->register();
    }

    /**
     * Registers services related to the module
     *
     * @param DiInterface $di
     */
    public function registerServices(DiInterface $di)
    {
        $di->get('dispatcher')->setDefaultNamespace('Registro\Backend\Controllers');

        /**
         * @var $view \Phalcon\Mvc\View
         */
        $view = $di->get( 'view' );
        $config = $di->get( 'config' );
        //$view->setLayout('frontend');
        $view->setViewsDir( $config->application->modulesDir . '/backend/views/' );
        $view->setLayoutsDir( $config->application->modulesDir . '/common/layouts/' );
        $view->setPartialsDir( $config->application->modulesDir . '/common/partials/' );

        $di->set( 'view', $view );
    }
}
