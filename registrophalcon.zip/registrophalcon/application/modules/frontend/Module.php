<?php

namespace Registro\Frontend;

use Phalcon\Loader;
use Phalcon\Mvc\View;
use Phalcon\DiInterface;
use Phalcon\Mvc\Dispatcher;
use Phalcon\Mvc\ModuleDefinitionInterface;
use Phalcon\Db\Adapter\Pdo\Mysql as MySQLAdapter;

class Module implements ModuleDefinitionInterface {

    /**
     * Registers the module auto-loader
     *
     * @param DiInterface $di
     */
    public function registerAutoloaders( DiInterface $di = null )
    {
        $loader = new Loader();
        $config = $di->get( 'config' );
        $loader->registerNamespaces(
                [
                    'Registro\Common\Controllers' => $config->application->modulesDir . '/common/controllers/',
                    'Registro\Frontend\Controllers' => $config->application->modulesDir . '/frontend/controllers/',
                    'Registro\Frontend\Models' => $config->application->modulesDir . '/models/',
                    'Registro\Plugins' => '/var/www/registrophalcon/apps/plugins/'
                ]
        );

        $loader->register();
    }

    /**
     * Registers services related to the module
     *
     * @param DiInterface $di
     */
    public function registerServices( DiInterface $di )
    {
        /**
         * Read configuration
         */
        //$config = require __DIR__ . "/config/config.php";

        $di->get( 'dispatcher' )->setDefaultNamespace( 'Registro\Frontend\Controllers' );

        /**
         * Setting up the view component
         */
//        $view = $di->get('view');
//
//        $view->setViewsDir(__DIR__ . '/views/');
//        $view->setLayoutsDir( APPLICATION_PATH . '/common/layouts/');
//        $di->set('view', $view);

        /**
         * @var $view \Phalcon\Mvc\View
         */
        $view = $di->get( 'view' );
        $config = $di->get( 'config' );
        //$view->setLayout('frontend');
        $view->setViewsDir( $config->application->modulesDir . '/frontend/views/' );
        $view->setLayoutsDir( $config->application->modulesDir . '/common/layouts/' );
        $view->setPartialsDir( $config->application->modulesDir . '/common/partials/' );

        $di->set( 'view', $view );
    }

}
