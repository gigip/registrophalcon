<?php
namespace Registro\Frontend\Controllers;
use Registro\Common\Controllers\ControllerBase;

class IndexController extends ControllerBase
{
    public function initialize()
    { 
        parent::initialize();
        $this->breadcrumbs->add('crumb-home', null, ['linked' => false]);
    }
    
    public function indexAction()
    {

    }

}
