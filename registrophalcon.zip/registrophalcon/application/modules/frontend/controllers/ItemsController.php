<?php

namespace Registro\Frontend\Controllers;

use Registro\Common\Controllers\ControllerBase;
use Registro\Forms\ItemForm;
use Registro\Forms\ManufacturersForm;
use Registro\Forms\ModelsForm;
use Registro\Models\Item;
use Registro\Models\Manufacturer;
use Registro\Models\Model;
use Registro\Models\ItemCategory;
use \Phalcon\Mvc\View;
use Phalcon\Session\Bag;

class ItemsController extends ControllerBase {

    private $_form;
    private $_step;

    protected function initialize()
    {
        parent::initialize();

        $this->breadcrumbs->add( 'crumb-additem', null, ['linked' => false ] );
    }

    public function indexAction()
    {
        
    }

    public function addAction()
    {
//        $form = new ItemsForm;
//        $manufacturers_form = new ManufacturersForm(new Manufacturers);
//
//        $form->initializeByStep(1);
//        $this->view->pick('items/add/iteminfo');
//        $this->view->form = $form;
//        $this->view->manufacturers_form = $manufacturers_form;
    }

    public function getFormAction( $step = 1, $item_id = null )
    {
        $item_id = (!is_null( $item_id ) ? $item_id : (!empty( $this->session->get( 'itemInfo' ) ) ? $this->session->get( 'itemInfo' )->getItemId() : null));
        $this->_step = $step;

        if( !is_null( $item_id ) )
        {

            $item = Item::findFirst( [
                        "conditions" => "item_id = ?1",
                        "bind" => [
                            1 => $item_id,
                        ]
                    ] );

            if( !$item )
            {
                $this->_form = new ItemForm( new Item, ['step' => 1 ] );
                $this->flash->error( "User was not found" );
            }
            else
            {
                 $this->session->set( 'itemInfo', $item );
                //$this->_form = new ItemForm( $item, ['step' => $this->_step ] );
            }
        }
        else
        {
            if( empty($this->session->get( 'itemInfo' )))
            {
                $this->session->set( 'itemInfo', new Item );
            }
        }
        $this->_form = new ItemForm( $this->session->get( 'itemInfo' ), ['step' => $this->_step ] );


        if( $this->request->isPost() )
        {
            if( $this->_form->isValid( $this->request->getPost() ) )
            {

                $this->processForm( $this->request->getPost() );

                switch( $this->_step ){
                    case 1:
                        $this->_form = new ItemForm( $this->_form->getEntity(), ['step' => $this->_step ] );
                        break;

                    case 2:
                        $this->_form = new ItemForm( $this->_form->getEntity(), ['step' => $this->_step ] );
                        
                        break;
                }
            }
        }
        
        switch( $this->_step ){
            case 1:
                $this->view->pick( 'items/add/itemmodel' );
                break;
            case 2:
                $this->view->pick( 'items/add/iteminfo' );
                break;

            default:
                $this->view->pick( 'items/add/itemmodel' );
                break;
        }
        
        //TEST
//        $this->view->pick( 'items/add/iteminfo' );
//        $form = new ItemForm( new Item, ['step' => 2 ] );

        $this->view->setRenderLevel(
                View::LEVEL_ACTION_VIEW
        );

        $item = $this->session->get( 'itemInfo' );

        if( !empty( $item ) )
        {

            $this->_form->setEntity( $item );
            if( !empty( $item->model ) )
            {
                $this->_form->bind( ['item_manufacturer_id' => $item->model->manufacturer->getManufacturerId(),
                    'item_manufacturer_name' => $item->model->manufacturer->getManufacturerName() ], $this->_form->getEntity() );

                $this->_form->bind( ['item_model_id' => $item->model->getModelId(),
                    'item_model_fullname' => $item->model->getModelFullName() ], $this->_form->getEntity() );
            }
        }
//        if( !empty( $item->itemCategory ) )
//        {
//            $this->_form->bind( ['item_category_id' => $this->session->get( 'itemInfo' )['category']->getCategoryId() ], $this->_form->getEntity() );
//        }
//

        echo "<pre>";
        var_dump($this->_step);
        echo "</pre>";
        
        $this->view->form = $this->_form;
        //$this->view->itemInfo = $this->session->get( 'itemInfo' );
        //Printing views output
        echo $this->view->getContent();
    }

    private function processForm( $data )
    {
        $item = $this->_form->getEntity();

        $item->setItemCreatedBy( $this->session->get( 'auth-identity' )->getUserId() );

        switch( $this->_step ){
            case 1:
                $this->session->set( 'itemInfo', $item );
                $this->_step = 2;
//                if( $item->save() )
//                {
//                    $this->session->set( 'itemInfo', $this->_form->getEntity() );
//                    $this->_step = 2;
//                }
//                else
//                {
//                    foreach( $item->getMessages() as $message ){
//                        $errors .= $message->getField() . '-' . $message->getMessage();
//                    }
//                    $this->flash->error( $this->view->t->_( 'errore' ) . $errors );
//                }
//                $itemInfo = [ ];
//                $itemInfo['category'] = ItemCategory::findFirst( ['category_id =' . $data['item_category_id'] ] );
//                $itemInfo['manufacturer'] = Manufacturer::findFirst( ['manufacturer_id =' . $data['item_manufacturer_id'] ] );
//                $itemInfo['model'] = Model::findFirst( ['model_id =' . $data['item_model_id'] ] );

                break;

            default:
                break;
        }
    }

}
