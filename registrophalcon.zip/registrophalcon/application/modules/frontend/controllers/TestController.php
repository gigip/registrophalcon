<?php
namespace Registro\Frontend\Controllers;
use Registro\Common\Controllers\ControllerBase;
use Phalcon\Paginator\Adapter\Model as Paginator;
class TestController extends ControllerBase
{
    public function indexAction()
    {

        $manufacturer = \Registro\Models\Manufacturer::findFirst(['manufacturer_id = 1']);
        foreach( $manufacturer->categories as $value ){
            echo "<pre>";
            var_dump($value->categories->category_name);
            echo "</pre>";
            //exit;
        }
        echo "<pre>";
        var_dump($manufacturer->categories);
        echo "</pre>";
        exit;
//        $user_username = 'asdè\' $asd';
//
//        $users = \Registro\Models\Users::findFirst(1);
//        echo "<pre>";
//        var_dump($_SESSION);
//        echo "</pre>";
//        exit;
//
//        $paginator = new Paginator(array(
//            "data"  => $users->regUsers,
//            "limit" => 10,
//            "page"  => 1
//        ));
//
//        $this->view->page = $paginator->getPaginate();        
//        $this->view->users = $users;
        
        //$this->view->var = ($this->auth->getIdentity());
    }
}
