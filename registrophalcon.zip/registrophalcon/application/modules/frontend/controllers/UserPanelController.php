<?php

namespace Registro\Frontend\Controllers;

use Registro\Common\Controllers\ControllerBase;

/**
 * Description of UserPanelController
 *
 * @author Gigi Pastore (gigi@la-fabbrica.org)
 */
class UserPanelController extends ControllerBase 
{
    protected function initialize()
    { 
        parent::initialize();
        $this->breadcrumbs->add('crumb-user', null, ['linked' => false]);
    }

    public function indexAction()
    {
//    echo "<pre>";
//    var_dump( $this->di);
//    echo "</pre>";
//    exit;
    }

}
