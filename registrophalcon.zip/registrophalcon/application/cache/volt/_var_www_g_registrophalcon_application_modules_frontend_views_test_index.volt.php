<?= $this->getContent() ?>

<form class="col-lg-12">
    <fieldset>
        <div class="row">
            <div class="form-group col-lg-8">
                <label for="exampleInputPassword1">Password</label>
                <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
                <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
            </div>
            <div class="col-lg-4">
                Col2
            </div>            
        </div>
        <div class="row has-danger">
            <label class="form-control-label col-lg-12" for="exampleSelect1">Example select</label>
            <div class="form-group col-lg-8">
                <select class="form-control" id="exampleSelect1">
                    <option>1</option>
                    <option>2</option>
                    <option>3</option>
                    <option>4</option>
                    <option>5</option>
                </select>                

                <div class="has-danger">
                    <span class="form-control-feedback">Il campo Costruttore è richiesto</span>
                </div>   
                <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
            </div>
            <div id="newManufacturer" class="col">
                
                <?= $this->tag->linkTo(['', '<i class="fa fa-plus-square"></i>' . $t->_('add_new_manufacturer'), 'class' => 'btn btn-primary btn-sm', 'data-toggle' => 'modal', 'data-target' => '#manufacturerFormModal']) ?>
            </div>           
        </div>
        <div class="row">
            <div class="form-group col-lg-8 has-success">
                <label class="form-control-label" for="inputSuccess1">Input with success</label>
                <input type="text" class="form-control form-control-success" id="inputSuccess1">
                <div class="form-control-feedback">Success! You've done it.</div>
            </div>            
            <div class="col-lg-4">
                Col2
            </div>              
        </div>
    </fieldset>
</form>


</tr>
</tbody>


