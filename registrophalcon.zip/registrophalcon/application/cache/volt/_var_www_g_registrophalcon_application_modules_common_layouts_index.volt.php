<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <!-- Latest compiled and minified CSS -->

<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />
<link href="/css/select2.css" rel="stylesheet" />
        <link rel="stylesheet" href="/css/font-awesome/css/font-awesome.min.css">
        <link rel="stylesheet" href="/css/bootstrap/bootstrap.css">
        <link rel="stylesheet" href="/css/reg.css">
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

        <!-- Optional theme -->


        <!-- Latest compiled and minified JavaScript -->
        <?= $this->tag->getTitle() ?>




    </head>
    <body>
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="//ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

        <script src="https://npmcdn.com/tether@1.2.4/dist/js/tether.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.5/js/bootstrap.js" type="text/javascript"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
            <?= $this->tag->javascriptInclude('http://ajax.aspnetcdn.com/ajax/jquery.validate/1.15.0/jquery.validate.js') ?>
            <?= $this->tag->javascriptInclude('http://ajax.aspnetcdn.com/ajax/jquery.validate/1.15.0/additional-methods.js') ?>
            <?= $this->tag->javascriptInclude('js/i18n/datepicker-it.js') ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.full.js"></script>
            <?= $this->tag->javascriptInclude('js/i18n/it.js') ?>
        <div class="container main-container">
                
        <?= $this->partial('header') ?>
<ol class="breadcrumb">
  <?= $this->breadcrumbs->output() ?>
</ol>
          <?= $this->getContent() ?>
        </div>
  
            <script src="/js/reg.js"></script>
    </body>
</html>
