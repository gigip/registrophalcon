<?= $this->getContent() ?>
<?= $this->tag->form(['class' => 'form-horizontal']) ?>
<div class="container half">
<div align="left">
    <h2><?= $t->_('LOGIN') ?></h2>
</div>

<form class="form-horizontal">
    <fieldset>
        <div class="form-group col-lg-12 <?php if (($form->hasMessagesFor('user_email'))) { ?> has-danger <?php } ?>">
            <?= $form->label('user_email', ['class' => 'control-label']) ?>
            <?= $form->render('user_email', ['class' => 'form-control']) ?>
            <?php if (($form->hasMessagesFor('user_email'))) { ?>
            <div class="form-control-feedback">
                <?php foreach ($form->getMessagesFor('user_email') as $message) { ?>
                    <?= $message ?><br />
                <?php } ?>
            </div>
            <?php } ?>         
        </div>
        <div class="form-group col-lg-12 <?php if (($form->hasMessagesFor('user_password'))) { ?> has-danger <?php } ?>">
            <?= $form->label('user_password', ['class' => 'control-label']) ?>
            <?= $form->render('user_password', ['class' => 'form-control']) ?>
            <?php if (($form->hasMessagesFor('user_password'))) { ?>
            <div class="form-control-feedback">
                <?php foreach ($form->getMessagesFor('user_password') as $message) { ?>
                    <?= $message ?><br />
                <?php } ?>
            </div>
            <?php } ?>              
        </div>
		<div class="form-group col-lg-12 form-check">
			<?= $form->render('remember') ?>
			<?= $form->label('remember') ?>
		</div>        
        <div class="col-lg-12 ">
            <?= $form->render($t->_('LOGIN'), ['class' => 'btn btn-success btn-block']) ?>
        </div>        
    </fieldset>
</form>






		<?= $form->render('csrf', ['value' => $this->security->getToken()]) ?>

		<hr>

		<div class="forgot">
			<?= $this->tag->linkTo(['session/forgotPassword', $t->_('FORGOT_PASSWORD')]) ?>
		</div>

	</form>

</div>