<!-- HEADER -->
<header id="header">
    <div id="logo-group">
        <span id="logo" style="font-size: 20px; width: 300px;"><?= $appTitle ?></span>
    </div>

    <nav class="navbar navbar-dark bg-inverse">
        <button class="navbar-toggler hidden-lg-up" type="button" data-toggle="collapse" data-target="#navbarResponsive3" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"></button>
        <div class="container collapse navbar-toggleable-md" id="navbarResponsive3">
            <ul class="nav navbar-nav"><?php $menus = ['Home' => 'index', 'Test' => 'test', 'Items' => 'items/add']; ?><?php foreach ($menus as $key => $value) { ?>
                <?php if ($value == $this->dispatcher->getControllerName()) { ?>
                    <li class="nav-item active"><?= $this->tag->linkTo([$value, $key, 'class' => 'nav-link']) ?></li>
                    <?php } else { ?>
                    <li class="nav-item"><?= $this->tag->linkTo([$value, $key, 'class' => 'nav-link']) ?></li>
                    <?php } ?><?php } ?></ul>
            <ul class="nav navbar-nav float-lg-right"><?php if (!(empty($logged_user))) { ?>
                <li><?= $this->tag->linkTo(['user_panel', ucwords($t->_('HI', ['user_firstname' => $logged_user->user_firstname])), 'class' => 'nav-link']) ?></li>

                <li class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="caret"></span></a>
                    <div class="dropdown-menu" aria-labelledby="supportedContentDropdown3">
                        <a class="dropdown-item" href="#">Action</a>
                        <a class="dropdown-item" href="#">Another action</a>
                        <a role="separator" class="divider"></a>
                        <<?= $this->tag->linkTo(['session/logout', $t->_('LOGOUT'), 'class' => 'dropdown-item']) ?>
                    </div>                    
                </li>                    
                <?php } else { ?>
                    <li class="nav-item"><?= $this->tag->linkTo(['session/signup', $t->_('SIGNUP'), 'class' => 'nav-link']) ?></li>
                    <li class="nav-item"><?= $this->tag->linkTo(['session/login', $t->_('LOGIN'), 'class' => 'nav-link']) ?></li>
                <?php } ?>   
            </ul>

        </div>
    </nav>
</header>
<!-- END HEADER -->