<?php

namespace Registro\Models;

class ItemModel extends ModelBase
{

    /**
     *
     * @var integer
     */
    protected $model_id;

    /**
     *
     * @var string
     */
    protected $model_code;

    /**
     *
     * @var string
     */
    protected $model_fullname;

    /**
     * Method to set the value of field model_id
     *
     * @param integer $model_id
     * @return $this
     */
    public function setModelId($model_id)
    {
        $this->model_id = $model_id;

        return $this;
    }

    /**
     * Method to set the value of field model_code
     *
     * @param string $model_code
     * @return $this
     */
    public function setModelCode($model_code)
    {
        $this->model_code = $model_code;

        return $this;
    }

    /**
     * Method to set the value of field model_fullname
     *
     * @param string $model_fullname
     * @return $this
     */
    public function setModelFullname($model_fullname)
    {
        $this->model_fullname = $model_fullname;

        return $this;
    }

    /**
     * Returns the value of field model_id
     *
     * @return integer
     */
    public function getModelId()
    {
        return $this->model_id;
    }

    /**
     * Returns the value of field model_code
     *
     * @return string
     */
    public function getModelCode()
    {
        return $this->model_code;
    }

    /**
     * Returns the value of field model_fullname
     *
     * @return string
     */
    public function getModelFullname()
    {
        return $this->model_fullname;
    }

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->hasMany('model_id', __NAMESPACE__ .'\Item', 'item_model_id', array('alias' => 'items'));
        $this->belongsTo('model_manufacturer_id', __NAMESPACE__ .'\Manufacturer', 'manufacturer_id', array('alias' => 'manufacturer'));
        
    }

    public function getSource()
    {
        return 'reg_models';
    }

    /**
     * Independent Column Mapping.
     * Keys are the real names in the table and the values their names in the application
     *
     * @return array
     */
    public function columnMap()
    {
        return array(
            'model_id' => 'model_id', 
            'model_manufacturer_id' => 'model_manufacturer_id',             
            'model_code' => 'model_code', 
            'model_fullname' => 'model_fullname'
        );
    }

}
