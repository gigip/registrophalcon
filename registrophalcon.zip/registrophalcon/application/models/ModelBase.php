<?php
namespace Registro\Models;
class ModelBase extends \Phalcon\Mvc\Model
{

    /**
    * Override default interface
    */
    public function getMessages( $filter = null )
    {
        $messages = parent::getMessages();
        foreach( $messages as $message ){

            switch( $message->getType()){
                case 'PresenceOf':
                    $message->setMessage(REQUIRED);
                    break;
                case 'Email':
                    $message->setMessage(INVALID_DATA);
                    break;

                default:
                    break;
            }
        }

        return $messages;
    }
}
