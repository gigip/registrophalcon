<?php

namespace Registro\Models;
use Phalcon\Validation;
use Phalcon\Validation\Validator\Uniqueness;
use Phalcon\Validation\Validator\Regex;
use Phalcon\Validation\Validator\Alpha;
class Model extends ModelBase
{

    /**
     *
     * @var integer
     */
    protected $model_id;

    /**
     *
     * @var integer
     */
    protected $model_manufacturer_id;

    /**
     *
     * @var string
     */
    protected $model_code;

    /**
     *
     * @var string
     */
    protected $model_fullname;

    /**
     * Method to set the value of field model_id
     *
     * @param integer $model_id
     * @return $this
     */
    public function setModelId($model_id)
    {
        $this->model_id = $model_id;

        return $this;
    }

    /**
     * Method to set the value of field model_manufacturer_id
     *
     * @param integer $model_manufacturer_id
     * @return $this
     */
    public function setModelManufacturerId($model_manufacturer_id)
    {
        $this->model_manufacturer_id = $model_manufacturer_id;

        return $this;
    }

    /**
     * Method to set the value of field model_code
     *
     * @param string $model_code
     * @return $this
     */
    public function setModelCode($model_code)
    {
        $this->model_code = $model_code;

        return $this;
    }

    /**
     * Method to set the value of field model_fullname
     *
     * @param string $model_fullname
     * @return $this
     */
    public function setModelFullname($model_fullname)
    {
        $this->model_fullname = $model_fullname;

        return $this;
    }

    /**
     * Returns the value of field model_id
     *
     * @return integer
     */
    public function getModelId()
    {
        return $this->model_id;
    }

    /**
     * Returns the value of field model_manufacturer_id
     *
     * @return integer
     */
    public function getModelManufacturerId()
    {
        return $this->model_manufacturer_id;
    }

    /**
     * Returns the value of field model_code
     *
     * @return string
     */
    public function getModelCode()
    {
        return $this->model_code;
    }

    /**
     * Returns the value of field model_fullname
     *
     * @return string
     */
    public function getModelFullname()
    {
        return $this->model_fullname;
    }

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->hasMany('model_id', __NAMESPACE__ . '\Item', 'item_model_id', array('alias' => 'items'));
        $this->belongsTo('model_manufacturer_id', __NAMESPACE__ . '\Manufacturer', 'manufacturer_id', array('alias' => 'manufacturer'));
    }

    public function getSource()
    {
        return 'reg_models';
    }

    public function beforeValidation()
    {
        $this->setModelCode($this->getModelFullname());
    }
    
    public function beforeSave()
    {
        $code = str_replace( ' ', '', $this->getModelFullname() );
        $code = strtoupper( $code );
        $this->setModelCode( $code );
    }
    
    /**
     * Validate data
     */
    public function validation()
    {
        $validator = new Validation();

        $validator->add( 'model_fullname', new Regex( [
            'pattern' => '/^[a-zA-Z0-9 -]+$/',
            'message' => INVALID_DATA
        ] ) );
//
//        $validator->add( 'user_email', new Email( [
//            "message" => INVALID_DATA
//        ] ) );
//
        $validator->add( ['model_manufacturer_id', 'model_fullname'], new Uniqueness( 
                [
                    //'field' => ['model_manufacturer_id', 'model_fullname'],
            "message" => 'model_duplicate'
        ] ) );
//
//        $validator->add( 'user_password', new StringLength( [
//            "min" => 8,
//            "messageMinimum" => SIGNUP_PASSWORD_TOO_SHORT
//        ] ) );

        return $this->validate( $validator );
    }    
    
    /**
     * Independent Column Mapping.
     * Keys are the real names in the table and the values their names in the application
     *
     * @return array
     */
    public function columnMap()
    {
        return array(
            'model_id' => 'model_id', 
            'model_manufacturer_id' => 'model_manufacturer_id', 
            'model_code' => 'model_code', 
            'model_fullname' => 'model_fullname'
        );
    }

}
