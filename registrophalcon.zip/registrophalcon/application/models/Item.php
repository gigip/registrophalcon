<?php

namespace Registro\Models;

class Item extends ModelBase {

    /**
     *
     * @var integer
     */
    protected $item_id;

    /**
     *
     * @var integer
     */
    protected $item_model_id;

    /**
     *
     * @var integer
     */
    protected $item_manufacturer_id;

    /**
     *
     * @var integer
     */
    protected $item_category_id;
    
    /**
     *
     * @var string
     */
    protected $item_serial_code;
    
    /**
     *
     * @var string
     */
    protected $item_purchase_date;    

    /**
     *
     * @var integer
     */
    protected $item_completed;
    
    /**
     *
     * @var string
     */
    protected $item_created;

    /**
     *
     * @var integer
     */
    protected $item_created_by;

    /**
     *
     * @var string
     */
    protected $item_modified;

    /**
     *
     * @var integer
     */
    protected $item_modified_by;

    /**
     * Method to set the value of field item_id
     *
     * @param integer $item_id
     * @return $this
     */
    public function setItemId( $item_id )
    {
        $this->item_id = $item_id;

        return $this;
    }

    /**
     * Method to set the value of field item_name
     *
     * @param integer $item_model_id
     * @return $this
     */
    public function setItemModelId( $item_model_id )
    {
        $this->item_model_id = $item_model_id;

        return $this;
    }

    /**
     * Method to set the value of field item_category_id
     *
     * @param integer $item_category_id
     * @return $this
     */
    public function setItemCategoryId( $item_category_id )
    {
        $this->item_category_id = $item_category_id;

        return $this;
    }

    /**
     * Method to set the value of field item_serial_code
     *
     * @param string $item_serial_code
     * @return $this
     */
    public function setItemSerialCode($item_serial_code)
    {
        $this->item_serial_code = $item_serial_code;

        return $this;
    }

    /**
     * Method to set the value of field item_purchase_date
     *
     * @param string $item_purchase_date
     * @return $this
     */
    public function setItemPurchaseDate($item_purchase_date)
    {
        $this->item_purchase_date = $item_purchase_date;

        return $this;
    }

    /**
     * Method to set the value of field item_completed
     *
     * @param integer $item_completed
     * @return $this
     */
    public function setItemCompleted($item_completed)
    {
        $this->item_completed = $item_completed;

        return $this;
    }
    
    /**
     * Method to set the value of field item_created
     *
     * @param string $item_created
     * @return $this
     */
    public function setItemCreated( $item_created )
    {
        $this->item_created = $item_created;

        return $this;
    }

    /**
     * Method to set the value of field item_created_by
     *
     * @param integer $item_created_by
     * @return $this
     */
    public function setItemCreatedBy( $item_created_by )
    {
        $this->item_created_by = $item_created_by;

        return $this;
    }

    /**
     * Method to set the value of field item_modified
     *
     * @param string $item_modified
     * @return $this
     */
    public function setItemModified( $item_modified )
    {
        $this->item_modified = $item_modified;

        return $this;
    }

    /**
     * Method to set the value of field item_modified_by
     *
     * @param integer $item_modified_by
     * @return $this
     */
    public function setItemModifiedBy( $item_modified_by )
    {
        $this->item_modified_by = $item_modified_by;

        return $this;
    }

    /**
     * Returns the value of field item_id
     *
     * @return integer
     */
    public function getItemId()
    {
        return $this->item_id;
    }

    /**
     * Returns the value of field item_model_id
     *
     * @return integer
     */
    public function getItemModelId()
    {
        return $this->item_model_id;
    }

    /**
     * Returns the value of field item_category_id
     *
     * @return integer
     */
    public function getItemCategoryId()
    {
        return $this->item_category_id;
    }

    /**
     * Returns the value of field item_serial_code
     *
     * @return string
     */
    public function getItemSerialCode()
    {
        return $this->item_serial_code;
    }

    /**
     * Returns the value of field item_purchase_date
     *
     * @return string
     */
    public function getItemPurchaseDate()
    {
        return $this->item_purchase_date;
    }

    /**
     * Returns the value of field item_completed
     *
     * @return integer
     */
    public function getItemCompleted()
    {
        return $this->item_completed;
    }
    
    /**
     * Returns the value of field item_created
     *
     * @return string
     */
    public function getItemCreated()
    {
        return $this->item_created;
    }

    /**
     * Returns the value of field item_created_by
     *
     * @return integer
     */
    public function getItemCreatedBy()
    {
        return $this->item_created_by;
    }

    /**
     * Returns the value of field item_modified
     *
     * @return string
     */
    public function getItemModified()
    {
        return $this->item_modified;
    }

    /**
     * Returns the value of field item_modified_by
     *
     * @return integer
     */
    public function getItemModifiedBy()
    {
        return $this->item_modified_by;
    }

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->hasMany( 'item_id', __NAMESPACE__ . '\ItemEvent', 'items_events_item_id', array( 'alias' => '_items_events' ) );
        $this->hasMany( 'item_id', __NAMESPACE__ . '\_pictures', 'picture_instrument_id', array( 'alias' => '_pictures' ) );
        $this->belongsTo( 'item_model_id', Model::class, 'model_id', array( 'alias' => 'model' ) );
        $this->belongsTo( 'item_created_by', User::class, 'user_id', array( 'alias' => '_users' ) );
        $this->belongsTo( 'item_modified_by', User::class, 'user_id', array( 'alias' => 'Reg_users' ) );
        $this->belongsTo( 'item_category_id', ItemCategory::class, 'category_id', array( 'alias' => 'itemCategory' ) );
    }

    public function getSource()
    {
        return 'reg_items';
    }

    /**
     * Independent Column Mapping.
     * Keys are the real names in the table and the values their names in the application
     *
     * @return array
     */
    public function columnMap()
    {
        return array(
            'item_id' => 'item_id',
            'item_model_id' => 'item_model_id',
            'item_category_id' => 'item_category_id',
            'item_serial_code' => 'item_serial_code',
            'item_purchase_date' => 'item_purchase_date',     
            'item_completed' => 'item_completed',             
            'item_created' => 'item_created',
            'item_created_by' => 'item_created_by',
            'item_modified' => 'item_modified',
            'item_modified_by' => 'item_modified_by'
        );
    }

}
