<?php

namespace Registro\Models;

class UserGroup extends ModelBase {

    /**
     *
     * @var integer
     */
    protected $group_id;

    /**
     *
     * @var string
     */
    protected $group_name;

    /**
     * Method to set the value of field group_id
     *
     * @param integer $group_id
     * @return $this
     */
    public function setGroupId( $group_id )
    {
        $this->group_id = $group_id;

        return $this;
    }

    /**
     * Method to set the value of field group_name
     *
     * @param string $group_name
     * @return $this
     */
    public function setGroupName( $group_name )
    {
        $this->group_name = $group_name;

        return $this;
    }

    /**
     * Returns the value of field group_id
     *
     * @return integer
     */
    public function getGroupId()
    {
        return $this->group_id;
    }

    /**
     * Returns the value of field group_name
     *
     * @return string
     */
    public function getGroupName()
    {
        return $this->group_name;
    }

    public function getSource()
    {
        return 'reg_user_groups';
    }     
    
    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->hasMany( 'group_id', __NAMESPACE__ . '\User', 'user_group_id', array( 'alias' => 'regUsers' ) );
    }

    /**
     * Independent Column Mapping.
     * Keys are the real names in the table and the values their names in the application
     *
     * @return array
     */
    public function columnMap()
    {
        return array(
            'group_id' => 'group_id',
            'group_name' => 'group_name'
        );
    }

}
