<?php

namespace Registro\Models;

use Phalcon\Validation;
use Phalcon\Validation\Validator\Regex;
use Phalcon\Validation\Validator\Uniqueness;

class Manufacturer extends ModelBase {

    /**
     *
     * @var integer
     */
    protected $manufacturer_id;

    /**
     *
     * @var string
     */
    protected $manufacturer_name;

    /**
     * Method to set the value of field manufacturer_id
     *
     * @param integer $manufacturer_id
     * @return $this
     */
    public function setManufacturerId( $manufacturer_id )
    {
        $this->manufacturer_id = $manufacturer_id;

        return $this;
    }

    /**
     * Method to set the value of field manufacturer_name
     *
     * @param string $manufacturer_name
     * @return $this
     */
    public function setManufacturerName( $manufacturer_name )
    {
        $this->manufacturer_name = $manufacturer_name;

        return $this;
    }

    /**
     * Returns the value of field manufacturer_id
     *
     * @return integer
     */
    public function getManufacturerId()
    {
        return $this->manufacturer_id;
    }

    /**
     * Returns the value of field manufacturer_name
     *
     * @return string
     */
    public function getManufacturerName()
    {
        return $this->manufacturer_name;
    }

    public function getSource()
    {
        return 'reg_manufacturers';
    }

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->hasMany( 'manufacturer_id', Item::class, 'item_manufacturer_id', array( 'alias' => 'items' ) );
        $this->hasMany('manufacturer_id', ManufacturersCategories::class, 'manufacturer_id', array('alias' => 'categories'));
        $this->hasManyToMany(
            "manufacturer_id",
            "ManufacturersCategories",
            "manufacturer_id", "category_id",
            "ItemCategory",
            "category_id"
        );
    }

    /**
     * Validate data
     */
    public function validation()
    {
        $validator = new Validation();

        $validator->add( 'manufacturer_name',
                new Regex( [
                    'pattern' => '/^[a-zA-Zàáèéìíòóùú0-9&\.\- ]+$/',
                    'message' => INVALID_DATA
                    ] ) 
                );
        
        $validator->add('manufacturer_name', 
                new Uniqueness( [
                    'message' => NOT_UNIQUE 
                    ] )
                );

        return $this->validate( $validator );
    }

    /**
     * Independent Column Mapping.
     * Keys are the real names in the table and the values their names in the application
     *
     * @return array
     */
    public function columnMap()
    {
        return array(
            'manufacturer_id' => 'manufacturer_id',
            'manufacturer_name' => 'manufacturer_name'
        );
    }

}
