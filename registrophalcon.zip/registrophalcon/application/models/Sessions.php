<?php

namespace Registro\Models;

class Sessions extends \Phalcon\Mvc\Model {

    /**
     *
     * @var integer
     */
    protected $session_id;

    /**
     *
     * @var string
     */
    protected $session_creation_date;

    /**
     *
     * @var integer
     */
    protected $session_user_id;

    /**
     *
     * @var string
     */
    protected $session_token;

    /**
     *
     * @var string
     */
    protected $session_useragent;

    /**
     * Method to set the value of field session_id
     *
     * @param integer $session_id
     * @return $this
     */
    public function setSessionId( $session_id )
    {
        $this->session_id = $session_id;

        return $this;
    }

    /**
     * Method to set the value of field session_creation_date
     *
     * @param string $session_creation_date
     * @return $this
     */
    public function setSessionCreationDate( $session_creation_date )
    {
        $this->session_creation_date = $session_creation_date;

        return $this;
    }

    /**
     * Method to set the value of field session_user_id
     *
     * @param integer $session_user_id
     * @return $this
     */
    public function setSessionUserId( $session_user_id )
    {
        $this->session_user_id = $session_user_id;

        return $this;
    }

    /**
     * Method to set the value of field session_token
     *
     * @param string $session_token
     * @return $this
     */
    public function setSessionToken( $session_token )
    {
        $this->session_token = $session_token;

        return $this;
    }

    /**
     * Method to set the value of field session_useragent
     *
     * @param string $session_useragent
     * @return $this
     */
    public function setSessionUseragent( $session_useragent )
    {
        $this->session_useragent = $session_useragent;

        return $this;
    }

    /**
     * Returns the value of field session_id
     *
     * @return integer
     */
    public function getSessionId()
    {
        return $this->session_id;
    }

    /**
     * Returns the value of field session_creation_date
     *
     * @return string
     */
    public function getSessionCreationDate()
    {
        return $this->session_creation_date;
    }

    /**
     * Returns the value of field session_user_id
     *
     * @return integer
     */
    public function getSessionUserId()
    {
        return $this->session_user_id;
    }

    /**
     * Returns the value of field session_token
     *
     * @return string
     */
    public function getSessionToken()
    {
        return $this->session_token;
    }

    /**
     * Returns the value of field session_useragent
     *
     * @return string
     */
    public function getSessionUseragent()
    {
        return $this->session_useragent;
    }
    /**
     * Before create the user assign a password
     */
    public function beforeValidationOnCreate()
    {
        // Timestamp the confirmaton
        //$this->setSessionCreationDate( time() );
    }
    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->belongsTo( 'session_user_id', __NAMESPACE__ . '\Users', 'user_id', array( 'alias' => 'regUsers' ) );
    }

    /**
     * Independent Column Mapping.
     * Keys are the real names in the table and the values their names in the application
     *
     * @return array
     */
    public function columnMap()
    {
        return array(
            'session_id' => 'session_id',
            'session_creation_date' => 'session_creation_date',
            'session_user_id' => 'session_user_id',
            'session_token' => 'session_token',
            'session_useragent' => 'session_useragent'
        );
    }

}
