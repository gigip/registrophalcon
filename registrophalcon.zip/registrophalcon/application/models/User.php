<?php

namespace Registro\Models;

use Phalcon\Validation;
use Phalcon\Validation\Validator\Uniqueness;
use Phalcon\Validation\Validator\Regex;
use Phalcon\Validation\Validator\Alnum;
use Phalcon\Validation\Validator\Email;
use Phalcon\Validation\Validator\StringLength;
use Phalcon\Filter;

class User extends ModelBase {

    const ACTIVE = 'A',
            INACTIVE = 'I',
            PENDING = 'P',
            BANNED = 'B';

    /**
     *
     * @var integer
     */
    protected $user_id;

    /**
     *
     * @var string
     */
    protected $user_username;

    /**
     *
     * @var string
     */
    protected $user_email;

    /**
     *
     * @var string
     */
    protected $user_password;

    /**
     *
     * @var string
     */
    protected $user_firstname;

    /**
     *
     * @var string
     */
    protected $user_lastname;

    /**
     *
     * @var integer
     */
    protected $user_group_id;

    /**
     *
     * @var integer
     */
    protected $user_change_password;

    /**
     *
     * @var string
     */
    protected $user_email_code;

    /**
     *
     * @var string
     */
    protected $user_status;

    /**
     *
     * @var string
     */
    protected $user_created;

    /**
     * Method to set the value of field user_id
     *
     * @param integer $user_id
     * @return $this
     */
    public function setUserId( $user_id )
    {
        $this->user_id = $user_id;

        return $this;
    }

    /**
     * Method to set the value of field user_username
     *
     * @param string $user_username
     * @return $this
     */
    public function setUserUsername( $user_username )
    {
        $this->user_username = $user_username;

        return $this;
    }

    /**
     * Method to set the value of field user_email
     *
     * @param string $user_email
     * @return $this
     */
    public function setUserEmail( $user_email )
    {
        $this->user_email = $user_email;

        return $this;
    }

    /**
     * Method to set the value of field user_password
     *
     * @param string $user_password
     * @return $this
     */
    public function setUserPassword( $user_password )
    {
        $this->user_password = $user_password;

        return $this;
    }

    /**
     * Method to set the value of field user_firstname
     *
     * @param string $user_firstname
     * @return $this
     */
    public function setUserFirstname( $user_firstname )
    {
        $this->user_firstname = strip_tags( $user_firstname );

        return $this;
    }

    /**
     * Method to set the value of field user_lastname
     *
     * @param string $user_lastname
     * @return $this
     */
    public function setUserLastname( $user_lastname )
    {
        $this->user_lastname = strip_tags( $user_lastname );

        return $this;
    }

    /**
     * Method to set the value of field user_group_id
     *
     * @param integer $user_group_id
     * @return $this
     */
    public function setUserGroupId( $user_group_id )
    {
        $this->user_group_id = $user_group_id;

        return $this;
    }

    /**
     * Method to set the value of field user_change_password
     *
     * @param integer $user_change_password
     * @return $this
     */
    public function setUserChangePassword( $user_change_password )
    {
        $this->user_change_password = $user_change_password;

        return $this;
    }

    /**
     * Method to set the value of field user_email_code
     *
     * @param string $user_email_code
     * @return $this
     */
    public function setUserEmailCode( $user_email_code )
    {
        $this->user_email_code = $user_email_code;

        return $this;
    }

    /**
     * Method to set the value of field user_status
     *
     * @param string $user_status
     * @return $this
     */
    public function setUserStatus( $user_status )
    {
        $this->user_status = $user_status;

        return $this;
    }

    /**
     * Method to set the value of field user_created
     *
     * @param string $user_created
     * @return $this
     */
    public function setUserCreated( $user_created )
    {
        $this->user_created = $user_created;

        return $this;
    }

    /**
     * Returns the value of field user_id
     *
     * @return integer
     */
    public function getUserId()
    {
        return $this->user_id;
    }

    /**
     * Returns the value of field user_username
     *
     * @return string
     */
    public function getUserUsername()
    {
        return $this->user_username;
    }

    /**
     * Returns the value of field user_email
     *
     * @return string
     */
    public function getUserEmail()
    {
        return $this->user_email;
    }

    /**
     * Returns the value of field user_password
     *
     * @return string
     */
    public function getUserPassword()
    {
        return $this->user_password;
    }

    /**
     * Returns the value of field user_firstname
     *
     * @return string
     */
    public function getUserFirstname()
    {
        return $this->user_firstname;
    }

    /**
     * Returns the value of field user_lastname
     *
     * @return string
     */
    public function getUserLastname()
    {
        return $this->user_lastname;
    }

    /**
     * Returns the value of field user_group_id
     *
     * @return integer
     */
    public function getUserGroupId()
    {
        return $this->user_group_id;
    }

    /**
     * Returns the value of field user_change_password
     *
     * @return integer
     */
    public function getUserChangePassword()
    {
        return $this->user_change_password;
    }

    /**
     * Returns the value of field user_email_code
     *
     * @return string
     */
    public function getUserEmailCode()
    {
        return $this->user_email_code;
    }

    /**
     * Returns the value of field user_status
     *
     * @return string
     */
    public function getUserStatus()
    {
        return $this->user_status;
    }

    /**
     * Returns the value of field user_created
     *
     * @return string
     */
    public function getUserCreated()
    {
        return $this->user_created;
    }

    /**
     * Initialize method for model.
     */
    public function initialize()
    {
        $this->hasMany( 'user_id', __NAMESPACE__ . '\Event', 'event_created_by', array( 'alias' => '_events' ) );
        $this->hasMany( 'user_id', __NAMESPACE__ . '\Event', 'event_modified_by', array( 'alias' => '_events' ) );
        $this->hasMany( 'user_id', __NAMESPACE__ . '\Item', 'item_created_by', array( 'alias' => '_items' ) );
        $this->hasMany( 'user_id', __NAMESPACE__ . '\Item', 'item_modified_by', array( 'alias' => '_items' ) );
        $this->hasMany( 'user_id', __NAMESPACE__ . '\Session', 'session_user_id', array( 'alias' => '_sessions' ) );
        $this->belongsTo( 'user_group_id', __NAMESPACE__ . '\UserGroup', 'group_id', array( 'alias' => 'userGroup' ) );
    }

    /**
     * Validate data
     */
    public function validation()
    {
        $validator = new Validation();

        $validator->add( 'user_username', new Alnum( [
            'message' => ALNUM_ONLY
        ] ) );

        $validator->add( [ 'user_firstname', 'user_lastname' ], new Regex( [
            'pattern' => '/^[a-zA-Zàáèéìíòóùú0-9\' ]+$/',
            'message' => INVALID_DATA
        ] ) );

        $validator->add( 'user_email', new Email( [
            "message" => INVALID_DATA
        ] ) );

        $validator->add( 'user_email', new Uniqueness( [
            "message" => SIGNUP_EMAIL_IN_USE
        ] ) );

        $validator->add( 'user_password', new StringLength( [
            "min" => 8,
            "messageMinimum" => SIGNUP_PASSWORD_TOO_SHORT
        ] ) );

        return $this->validate( $validator );
    }

    public function beforeSave()
    {
        $filter = new Filter();
        
        $filter->add(
                "hashPassword", function ($value){
                return $this->di->get( 'security' )->hash( $value );
            }
        );
        $this->setUserUsername( $filter->sanitize( $this->getUserUsername(), ["alphanum", "trim" ] ) );
        $this->setUserFirstname( $filter->sanitize( $this->getUserFirstname(), ["striptags", "trim" ] ) );
        $this->setUserLastname( $filter->sanitize( $this->getUserLastname(), ["striptags", "trim" ] ) );
        $this->setUserEmail( $filter->sanitize( $this->getUserEmail(), ["email", "trim" ] ) );
        $this->setUserPassword( $filter->sanitize( $this->getUserPassword(), "hashPassword" ) );
    }

    /**
     * Before create the user assign a password
     */
    public function beforeValidationOnCreate()
    {
//        if (empty($this->user_password)) {
//
//            // Generate a plain temporary password
//            $tempPassword = preplace('/[^a-zA-Z0-9]/', '', base64_encode(openssl_random_pseudo_bytes(12)));
//
//            // The user must change its password in first login
//            $this->user_mustchangepassword = true;
//
//            // Use this password as default
//            $this->user_password = $this->getDI()
//                ->getSecurity()
//                ->hash($tempPassword);
//        } else {
//            // The user must not change its password in first login
//            $this->user_mustchangepassword = false;
//        }
        // The account must be confirmed via e-mail
        // Only require this if emails are turned on in the config, otherwise account is automatically active
//        if ($this->getDI()->get('config')->useMail) {
//            $this->active = 'N';
//        } else {
//            $this->active = 'Y';
//        }

        $this->user_status = self::PENDING;
    }

    public function getSource()
    {
        return 'reg_users';
    }    
    
    /**
     * Independent Column Mapping.
     * Keys are the real names in the table and the values their names in the application
     *
     * @return array
     */
    public function columnMap()
    {
        return array(
            'user_id' => 'user_id',
            'user_username' => 'user_username',
            'user_email' => 'user_email',
            'user_password' => 'user_password',
            'user_firstname' => 'user_firstname',
            'user_lastname' => 'user_lastname',
            'user_group_id' => 'user_group_id',
            'user_change_password' => 'user_change_password',
            'user_email_code' => 'user_email_code',
            'user_status' => 'user_status',
            'user_created' => 'user_created'
        );
    }

}
