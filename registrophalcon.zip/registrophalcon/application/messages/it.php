<?php
$messages = [
    'LOGIN'               => "Accedi",
//    SIGNUP              => "Registrati",
//    LOGOUT              => "Esci",
//    HI                  => "Ciao %user_firstname%",
//    no_results_found    => 'Nessun risultato trovato',
//    save                => 'Salva',
//    close               => 'Chiudi',
//    cancel              => 'Annulla',
//    proceed             => 'Procedi',
//    error               => 'Errore',
//    success             => 'Operazione eseguita con successo',
//    
//    /*
//     * Breadcrumbs
//     */
//    'crumb-home'     => 'Home',
//    'crumb-user'     => 'User',
//    'crumb-settings' => 'Settings',
//    'crumb-profile'  => 'Profile',
//    'crumb-additem'  => 'Aggiungi strumento',
//    
//    /*
//     * Forms (generic)
//     */
//    SEND                => 'Invia',
//    REQUIRED            => "Il campo %field% è richiesto",
//    invalid_data           => "Il campo %field% non è nel formato richiesto",
//    ALNUM_ONLY             => "Il campo %field% può contenere solo lettere e numeri",
//    STRING_LENGTH           => "Il campo %field% deve contenere almeno 8 caratteri",
//    FORGOT_PASSWORD_LEGEND => 'Password dimenticata?',
//    NOT_UNIQUE              => 'Esiste già un %field% con questo nome.',
//    
//    /*
//     * Login Form
//     */
//    LOGIN_USER_NOT_FOUND      => "Utente non trovato",
//    LOGIN_INVALID_CREDENTIAL  => "Email o password non corrette",
//    LOGIN_REMEMBER_ME         => 'Ricordami su questo computer',
//    FORGOT_PASSWORD           => 'Password dimenticata?',
//    "song"    => "This song is %song%",
//    
//    /*
//     * SignUp Form
//     */
//    SIGNUP_LEGEND              => 'Compila il modulo per registrarti',
//    USER_USERNAME       => 'Username',
//    USER_FIRSTNAME      => 'Nome',
//    USER_LASTNAME       => 'Cognome',
//    USER_EMAIL          => 'Email',
//    USER_PASSWORD       => 'Password',
//    SIGNUP_CONFIRM_PASSWORD    => 'Conferma la password',
//    SIGNUP_ACCEPT_TERMS        => 'Accetto le Condizioni e i Termini del servizio',
//    SIGNUP_EMAIL_HELP          => 'Non condivideremo la tua email con nessuno',
//    SIGNUP_EMAIL_IN_USE        => 'Esiste già un utente con questa email',
//    SIGNUP_PASSWORD_TOO_SHORT  => 'La password deve contenere almeno 8 caratteri',
//    SIGNUP_PASSWORD_NO_MARCH   => 'Le due password non coincidono',
//    SIGNUP_PASSWORD_HELP       => 'La password deve contenere almeno 8 caratteri',
//    SIGNUP_TERMS_MUST_BE_ACCEPTED => 'Per proseguire è necessario accettare le Condizioni e i Termini del servizio',
//    
//    /*
//     * ManufacturersForm
//     */
//    item_manufacturer_name => 'Costruttore',
//    manufacturer_name => 'Nome costruttore',
//    item_model_fullname => 'Modello',
//    
//    /*
//     * ModelsForm
//     */
//    model_manufacturer_name => 'Costruttore',
//    model_fullname => 'Modello',
//    model_fullname_help => 'Inserisci il nome bla bla bla...',
//    model_duplicate => 'Esiste già un modello con questo nome',
//    /*
//     * AddNewItem Form
//     */
//    add_new_manufacturer    => 'Aggiungi Nuovo Costruttore',
//    select_manufacturer => 'Seleziona un Costruttore...',
//    select_model => 'Seleziona un Modello...',
//    select_category => 'Seleziona una Categoria',
//    add_new_model => 'Aggiungi Nuovo Modello',
//    manufacturer_help => 'Digita il nome di un costruttore, oppure aggiungine uno nuovo'
    
];