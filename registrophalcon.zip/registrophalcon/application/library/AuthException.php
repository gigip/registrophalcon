<?php
namespace Registro\Auth;

class AuthException extends \Phalcon\Exception
{
}
