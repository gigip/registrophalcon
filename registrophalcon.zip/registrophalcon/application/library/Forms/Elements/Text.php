<?php

/**
 * Description of Text
 *
 * @author Gigi Pastore (gigi@la-fabbrica.org)
 */

namespace Registro\Forms\Elements;

class Text extends \Phalcon\Forms\Element\Text {

    public function __construct( $name, $parameters = array() )
    {
        parent::__construct( $name, $parameters = array() );

        $this->setLabel(
                \Phalcon\DI::getDefault()
                        ->getTranslator()
                        ->_( $this->getName() )
        );
    }

    public function label( $attributes = null )
    {
        $attributes['class'] = $attributes['class'] . ' form-control-label';

        return parent::label( $attributes );
    }
    
    public function render( $attributes = null )
    {
        $attributes['class'] = $attributes['class'] . ' form-control';

        return parent::render($attributes);        
    }

}
