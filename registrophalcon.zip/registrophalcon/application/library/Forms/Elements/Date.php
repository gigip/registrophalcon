<?php

/**
 * Description of Text
 *
 * @author Gigi Pastore (gigi@la-fabbrica.org)
 */

namespace Registro\Forms\Elements;

class Date extends \Phalcon\Forms\Element\Date {

    public function __construct( $name, $parameters = array() )
    {
        parent::__construct( $name, $parameters = array() );

        $this->setLabel(
                \Phalcon\DI::getDefault()
                        ->getTranslator()
                        ->_( $this->getName() )
        );
    }

    public function label( $attributes = null )
    {
        $attributes = array_merge( ['class' => 'control-label' ], $attributes );

        return parent::label( $attributes );
    }
    
    public function render( $attributes = null )
    {
        $attributes['class'] = $attributes['class'] . ' form-control';

        return parent::render($attributes);        
    }

}
