<?php

/**
 * Description of Text
 *
 * @author Gigi Pastore (gigi@la-fabbrica.org)
 */

namespace Registro\Forms\Elements;

class Select extends \Phalcon\Forms\Element\Select {

    public function __construct( $name, $options = null, $attributes = null )
    {
        parent::__construct( $name, $options, $attributes );

        $this->setAttribute( 'class', 'form-control' );

        $this->setLabel(
                \Phalcon\DI::getDefault()
                        ->getTranslator()
                        ->_( $this->getName() )
        );
    }

    public function label( $attributes = null )
    {
        $attributes['class'] = $attributes['class'] . ' form-control-label';

        return parent::label( $attributes );
    }

}
