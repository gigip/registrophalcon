<?php

/**
 * Description of Text
 *
 * @author Gigi Pastore (gigi@la-fabbrica.org)
 */

namespace Registro\Forms\Elements;

class Submit extends \Phalcon\Forms\Element\Submit {

    public function __construct( $name, $parameters = array() )
    {
        parent::__construct( $name, $parameters = array() );

        $this->setAttribute( 'class', 'btn btn-success' );
    }

    public function render( $attributes = array() )
    {
        $this->setName(
                \Phalcon\DI::getDefault()
                        ->getTranslator()
                        ->_( $this->getName() )
        );
        return parent::render( $attributes );
    }
}