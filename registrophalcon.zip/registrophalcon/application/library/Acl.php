<?php
namespace Registro;

use Phalcon\Mvc\User\Component;
//use Phalcon\Acl\Adapter\Memory as AclMemory;
//use Phalcon\Acl\Role as AclRole;
//use Phalcon\Acl\Resource as AclResource;
//use Vokuro\Models\Profiles;
use Phalcon\Mvc\User\Plugin;
use Registro\Models\UserGroup;

/**
 * Vokuro\Acl\Acl
 */
class Acl extends Plugin
{

    /**
     * The ACL Object
     *
     * @var \Phalcon\Acl\Adapter\Memory
     */
    private $acl;

    /**
     * The file path of the ACL cache file.
     *
     * @var string
     */
    private $filePath;

    /**
     * Define the resources that are considered "private". These controller => actions require authentication.
     *
     * @var array
     */
    private $privateResources = array();

    /**
     * Human-readable descriptions of the actions used in {@see $privateResources}
     *
     * @var array
     */
    private $actionDescriptions = [
        'index' => 'Access',
        'search' => 'Search',
        'create' => 'Create',
        'edit' => 'Edit',
        'delete' => 'Delete',
        'changePassword' => 'Change password'
    ];

    /**
     * Checks if a controller is private or not
     *
     * @param string $controllerName
     * @return boolean
     */
    public function isPrivate($controllerName)
    {
        $controllerName = strtolower($controllerName);
        return isset($this->privateResources[$controllerName]);
    }

    /**
     * Checks if the current profile is allowed to access a resource
     *
     * @param string $profile
     * @param string $controller
     * @param string $action
     * @return boolean
     */
    public function isAllowed($profile, $controller, $action, $param = null)
    {
        return $this->getAcl()->isAllowed($profile, $controller, $action, $param);
    }

    /**
     * Returns the ACL list
     *
     * @return \Phalcon\Acl\Adapter\Memory
     */
    public function getAcl()
    {

        // Create the ACL
        $acl = new \Phalcon\Acl\Adapter\Memory();

        // The default action is DENY access
        $acl->setDefaultAction(\Phalcon\Acl::DENY);
        
        // Change no arguments default action
        $acl->setNoArgumentsDefaultAction(\Phalcon\Acl::DENY);
        
        // Register roles
//        $roles = array(
//            'admin'   => new \Phalcon\Acl\Role('admin'),
//            'guest'    => new \Phalcon\Acl\Role('guest')
//        );
        
        $roles = UserGroup::find();

        // Adding Roles to the ACL
        foreach ($roles as $role) {
            $acl->addRole(new \Phalcon\Acl\Role($role->groupName));
        }

        // Adding Resources (controllers/actions)
        // resources allowed for all groups
        $publicResources = $this->config->publicResources; 

        foreach ($publicResources as $resource => $actions) {
            $acl->addResource(new \Phalcon\Acl\Resource($resource), $actions->toArray());
        }

        $privateResources = $this->config->privateResources; 
        
        foreach ($privateResources as $resource => $actions) {
            $acl->addResource(new \Phalcon\Acl\Resource($resource), $actions->toArray());
        }

        // Defining Access Controls
        // Grant access to public areas to all roles
        foreach ($roles as $role) {
            foreach ($publicResources as $resource => $actions) {
                foreach ($actions as $action) {
                    $acl->allow($role->getGroupName(), $resource, $action);
                }
            }
        }
//        echo "<pre>";
//        var_dump($this->isAllowed($role, $module.'-'.$controller, $action));
//        echo "</pre>";
//        exit;
        // Grant access to private area only to certain roles
        foreach ($privateResources as $resource => $actions) {
            foreach ($actions as $action) {
                $acl->allow($roles[0]->getGroupName(), $resource, $action);
            }
        }

        $acl->allow($roles[0]->getGroupName(), 'frontend-items', 'add',    function ($a) {
            return $a === 'A';
        });
        $acl->allow('*', 'frontend-items', 'add',    function ($a) {
            echo "<pre>";
            var_dump($a);
            echo "</pre>";
            exit;
            return $a === 'A';
        });        
        
        return $acl;
    }

    /**
     * Returns the permissions assigned to a profile
     *
     * @param Profiles $profile
     * @return array
     */
    public function getPermissions(Profiles $profile)
    {
        $permissions = [];
        foreach ($profile->getPermissions() as $permission) {
            $permissions[$permission->resource . '.' . $permission->action] = true;
        }
        return $permissions;
    }

    /**
     * Returns all the resources and their actions available in the application
     *
     * @return array
     */
    public function getResources()
    {
        return $this->privateResources;
    }

    /**
     * Returns the action description according to its simplified name
     *
     * @param string $action
     * @return string
     */
    public function getActionDescription($action)
    {
        if (isset($this->actionDescriptions[$action])) {
            return $this->actionDescriptions[$action];
        } else {
            return $action;
        }
    }

    /**
     * Rebuilds the access list into a file
     *
     * @return \Phalcon\Acl\Adapter\Memory
     */
    public function rebuild()
    {
        $acl = new AclMemory();

        $acl->setDefaultAction(\Phalcon\Acl::DENY);

        // Register roles

        $profiles = Profiles::find([
            'active = :active:',
            'bind' => [
                'active' => 'Y'
            ]
        ]);
        foreach ($profiles as $profile) {
            $acl->addRole(new AclRole($profile->name));
        }

        foreach ($this->privateResources as $resource => $actions) {
            $acl->addResource(new AclResource($resource), $actions);
        }

        // Grant access to private area to role Users
        foreach ($profiles as $profile) {

            // Grant permissions in "permissions" model
            foreach ($profile->getPermissions() as $permission) {
                $acl->allow($profile->name, $permission->resource, $permission->action);
            }

            // Always grant these permissions
            $acl->allow($profile->name, 'users', 'changePassword');
        }

        $filePath = $this->getFilePath();

        if (touch($filePath) && is_writable($filePath)) {

            file_put_contents($filePath, serialize($acl));

            // Store the ACL in APC
            if (function_exists('apc_store')) {
                apc_store('vokuro-acl', $acl);
            }
        } else {
            $this->flash->error(
                'The user does not have write permissions to create the ACL list at ' . $filePath
            );
        }

        return $acl;
    }


    /**
     * Set the acl cache file path
     *
     * @return string
     */
    protected function getFilePath()
    {
        if (!isset($this->filePath)) {
            $this->filePath = $this->config->application->cacheDir . '/acl/data.txt';
        }

        return $this->filePath;
    }

    /**
     * Adds an array of private resources to the ACL object.
     * 
     * @param array $resources
     */
    public function addPrivateResources(array $resources) {
        if (count($resources) > 0) {
            $this->privateResources = array_merge($this->privateResources, $resources);
            if (is_object($this->acl)) {
                $this->acl = $this->rebuild();
            }
        }
    }
}
