<?php

namespace Registro;
/**
 * Description of Flash
 *
 * @author Gigi Pastore (gigi@la-fabbrica.org)
 */
class Flash extends \Phalcon\Flash\Direct{
    
    /**
     * Correctly escapes the message while building a Bootstrap 3
     * compatible dismissable message with surrounding html.
     * @param string $type
     * @param string $message
     * @return void
     */
    public function message($type, $message)
    {
        $bootstrapCssClass = $this->_cssClasses[$type];
        $errorType = ucfirst($type);
        $bootstrapMessage = "<div class=\"alert alert-{$bootstrapCssClass} alert-dismissible\" role=\"alert\"><button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button><strong>{$errorType}:</strong> {$this->getEscaperService()->escapeHtml($message)}</div>";
        parent::message($type, $bootstrapMessage);
    }
}
