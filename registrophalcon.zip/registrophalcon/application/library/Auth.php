<?php
namespace Registro;

use Phalcon\Mvc\User\Plugin;
use Registro\Models\User;
use Registro\Models\Session;
use Registro\RegException;

/**
 * Registro\Auth\Auth
 * Manages Authentication/Identity Management in Registro
 */
class Auth extends Plugin
{
    /**
     * Checks the user credentials
     *
     * @param array $credentials
     * @return boolean
     * @throws Exception
     */
    public function check($credentials)
    {

        // Check if the user exist
        $user = User::findFirstByUserEmail($credentials['user_email']);
        if ($user == false) {
            $this->registerUserThrottling(0);
            throw new RegException(LOGIN_USER_NOT_FOUND);
        }

        // Check the password
        if (!$this->security->checkHash($credentials['user_password'], $user->getUserPassword())) {
            $this->registerUserThrottling($user->getUserId());
            throw new RegException(LOGIN_INVALID_CREDENTIAL);
        }

        // Check if the user was flagged
        $this->checkUserFlags($user);

        // Register the successful login
        //$this->saveSuccessLogin($user);

        // Check if the remember me was selected
        if (isset($credentials['remember'])) {
            $this->createRememberEnvironment($user);
        }

        $this->session->set('auth-identity', $user);
    }

    /**
     * Creates the remember me environment settings the related cookies and generating tokens
     *
     * @param \Registro\Models\Users $user
     * @throws Exception
     */
    public function saveSuccessLogin($user)
    {
        $successLogin = new SuccessLogins();
        $successLogin->usersId = $user->id;
        $successLogin->ipAddress = $this->request->getClientAddress();
        $successLogin->userAgent = $this->request->getUserAgent();
        if (!$successLogin->save()) {
            $messages = $successLogin->getMessages();
            throw new AuthException($messages[0]);
        }
    }

    /**
     * Implements login throttling
     * Reduces the effectiveness of brute force attacks
     *
     * @param int $userId
     */
    public function registerUserThrottling($userId)
    {
//        $failedLogin = new FailedLogins();
//        $failedLogin->usersId = $userId;
//        $failedLogin->ipAddress = $this->request->getClientAddress();
//        $failedLogin->attempted = time();
//        $failedLogin->save();
//
//        $attempts = FailedLogins::count([
//            'ipAddress = ?0 AND attempted >= ?1',
//            'bind' => [
//                $this->request->getClientAddress(),
//                time() - 3600 * 6
//            ]
//        ]);
//
//        switch ($attempts) {
//            case 1:
//            case 2:
//                // no delay
//                break;
//            case 3:
//            case 4:
//                sleep(2);
//                break;
//            default:
//                sleep(4);
//                break;
//        }
    }

    /**
     * Creates the remember me environment settings the related cookies and generating tokens
     *
     * @param \Registro\Models\Users $user
     */
    public function createRememberEnvironment(User $user)
    {
        $userAgent = $this->request->getUserAgent();
        $token = md5($user->getUserEmail() . $user->getUserPassword() . $userAgent);

        $session = new Session();
        $session->setSessionUserId($user->getUserId());
        $session->setSessionToken($token);
        $session->setSessionUseragent($userAgent);

        if ($session->save() != false) {
            $expire = time() + 86400 * 8;
            $this->cookies->set('RMU', $user->getUserId(), $expire);
            $this->cookies->set('RMT', $token, $expire);
        }
    }

    /**
     * Check if the session has a remember me cookie
     *
     * @return boolean
     */
    public function hasRememberMe()
    {
        return $this->cookies->has('RMU');
    }

    /**
     * Logs on using the information in the cookies
     *
     * @return \Phalcon\Http\Response
     */
    public function loginWithRememberMe()
    {
        $userId = $this->cookies->get('RMU')->getValue();
        $cookieToken = $this->cookies->get('RMT')->getValue();

        $user = Users::findFirstById($userId);
        if ($user) {

            $userAgent = $this->request->getUserAgent();
            $token = md5($user->email . $user->password . $userAgent);

            if ($cookieToken == $token) {

                $remember = RememberTokens::findFirst([
                    'usersId = ?0 AND token = ?1',
                    'bind' => [
                        $user->id,
                        $token
                    ]
                ]);
                if ($remember) {

                    // Check if the cookie has not expired
                    if ((time() - (86400 * 8)) < $remember->createdAt) {

                        // Check if the user was flagged
                        $this->checkUserFlags($user);

                        // Register identity
                        $this->session->set('auth-identity', [
                            'id' => $user->id,
                            'name' => $user->name,
                            'profile' => $user->profile->name
                        ]);

                        // Register the successful login
                        $this->saveSuccessLogin($user);

                        return $this->response->redirect('users');
                    }
                }
            }
        }

        $this->cookies->get('RMU')->delete();
        $this->cookies->get('RMT')->delete();

        return $this->response->redirect('session/login');
    }

    /**
     * Checks if the user is banned/inactive/suspended
     *
     * @param \Registro\Models\Users $user
     * @throws Exception
     */
    public function checkUserFlags(User $user)
    {
        if( $user->getUserStatus() == User::INACTIVE)
        {
            throw new RegException(USER_INACTIVE);
        }

        if( $user->getUserStatus() == User::PENDING)
        {
            throw new RegException(USER_PENDING);
        }
        
        if( $user->getUserStatus() == User::BANNED)
        {
            throw new RegException(USER_BANNED);
        }        
//        if ($user->getUserStatus() != 'Y') {
//            throw new AuthException('The user is inactive');
//        }
//
//        if ($user->banned != 'N') {
//            throw new AuthException('The user is banned');
//        }
//
//        if ($user->suspended != 'N') {
//            throw new AuthException('The user is suspended');
//        }
    }

    /**
     * Returns the current identity
     *
     * @return array
     */
    public function getIdentity()
    {
        return $this->session->get('auth-identity');
    }

    /**
     * Returns the current identity
     *
     * @return string
     */
    public function getName()
    {
        $identity = $this->session->get('auth-identity');
        return $identity['name'];
    }

    /**
     * Removes the user identity information from session
     */
    public function remove()
    {
        if ($this->cookies->has('RMU')) {
            $this->cookies->get('RMU')->delete();
        }
        if ($this->cookies->has('RMT')) {
            $this->cookies->get('RMT')->delete();
        }

        $this->session->remove('auth-identity');
    }

    /**
     * Auths the user by his/her id
     *
     * @param int $id
     * @throws Exception
     */
    public function authUserById($id)
    {
        
        $user = Users::findFirstByUserId($id);
        if ($user == false) {
            throw new RegException('The user does not exist');
        }

        $this->checkUserFlags($user);

        $this->session->set('auth-identity', $user);
    }

    /**
     * Get the entity related to user in the active identity
     *
     * @return \Registro\Models\Users
     * @throws Exception
     */
    public function getUser()
    {
        $identity = $this->session->get('auth-identity');
        if (isset($identity['id'])) {

            $user = Users::findFirstById($identity['id']);
            if ($user == false) {
                throw new AuthException('The user does not exist');
            }

            return $user;
        }

        return false;
    }
}
