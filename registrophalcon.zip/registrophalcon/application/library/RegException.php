<?php
namespace Registro;
/**
 * Description of RegException
 *
 * @author Gigi Pastore (gigi@la-fabbrica.org)
 */
class RegException extends \Phalcon\Exception{
}
