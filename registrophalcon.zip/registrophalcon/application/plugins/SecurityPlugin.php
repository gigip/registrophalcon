<?php
/**
* ACL for the application
*/
//namespace Registro\Plugins;
use Phalcon\Events\Event,
    Phalcon\Mvc\User\Plugin,
    Phalcon\Mvc\Dispatcher,
    Phalcon\Acl,
    Phalcon\DI\FactoryDefault as PhDi;

class SecurityPlugin extends Plugin
{
    /**
     * Define the resources that are considered "private". These controller => actions require authentication.
     *
     * @var array
     */
    private $_privateResources = array();    
    
    public function beforeDispatch(Event $event, Dispatcher $dispatcher)
    {
       
        $di = PhDi::getDefault();

        // global config
        $config = $di->get('config');

        // Take the active controller/action from the dispatcher
        $module = $dispatcher->getModuleName() ? $dispatcher->getModuleName() : 'frontend';
        $controller = $dispatcher->getControllerName();
        $action = $dispatcher->getActionName();

        // Check whether the "auth" variable exists in session to define the active role
        $auth = $this->session->get('auth');

        if ( !$auth ) {

            $role = 'Guest';
        } else {
            $role = $auth['role'];
        }      
        
        // Check whether acl data already exist
//        $aclFileName = $config->application['securityDir'] . "acl.data";
//        if ( !is_file($aclFileName) ) {
//
//            // Obtain the ACL list
//            $acl = $this->getAcl();
//
//            // Store serialized list into plain file
//            file_put_contents($aclFileName, serialize($acl));
//
//        } else {
//
//            //Restore acl object from serialized file
//            $acl = unserialize(file_get_contents($aclFileName));
//        }
        $acl = $this->getDi()->getAcl();

        // Check if the Role have access to the controller (resource)
        $allowed = $acl->isAllowed($role, $module.'-'.$controller, $action);
//        echo "<pre>";
//        var_dump($allowed);
//        var_dump($role);
//        var_dump($module.'-'.$controller);
//        var_dump($action);
//        echo "</pre>";
//        exit;
        if ( $allowed != Acl::ALLOW ) {

            
            // If user doesn't have access forward to the index controller
            $dispatcher->setModuleName('frontend');
            $this->flash->notice('You don\'t have access to this module: ' . $module .'-'. $controller . ':' . $action);
            
            $dispatcher->forward(
                array(
                            'namespace' => 'Registro\Frontend\Controllers',
                            'module' => 'common',
                    'controller' => 'index',
                    'action' => 'index'
                )
            );
            
            // Returning "false" will tell to the dispatcher to stop the current operation
            return false;
        }

    }

    public function getAcl()
    {

        // Create the ACL
        $acl = new Phalcon\Acl\Adapter\Memory();

        // The default action is DENY access
        $acl->setDefaultAction(Phalcon\Acl::DENY);

        // Register roles
        $roles = array(
            'admin'   => new Phalcon\Acl\Role('admin'),
            'guest'    => new Phalcon\Acl\Role('guest')
        );
        
        // Adding Roles to the ACL
        foreach ($roles as $role) {
            $acl->addRole($role);
        }

        // Adding Resources (controllers/actions)
        // resources allowed for all groups
        $publicResources = $this->config->publicResources; 

        foreach ($publicResources as $resource => $actions) {
            $acl->addResource(new Phalcon\Acl\Resource($resource), $actions->toArray());
        }

        $privateResources = $this->config->privateResources; 
        
        foreach ($privateResources as $resource => $actions) {
            $acl->addResource(new Phalcon\Acl\Resource($resource), $actions->toArray());
        }

        // Defining Access Controls
        // Grant access to public areas to all roles
        foreach ($roles as $role) {
            foreach ($publicResources as $resource => $actions) {
                foreach ($actions as $action) {
                    $acl->allow($role->getName(), $resource, $action);
                }
            }
        }

        // Grant access to private area only to certain roles
        foreach ($privateResources as $resource => $actions) {
            foreach ($actions as $action) {
                $acl->allow($roles['admin']->getName(), $resource, $action);
            }
        }

        return $acl;
    }

}