<?php

namespace Registro\Forms;

use Phalcon\Forms\Form;
use Registro\Forms\Elements\Text;
use Phalcon\Forms\Element\Password;
use Registro\Forms\Elements\Submit;
use Phalcon\Forms\Element\Check;
use Phalcon\Forms\Element\Hidden;
use Phalcon\Validation\Validator\PresenceOf;
use Phalcon\Validation\Validator\Email;
use Phalcon\Validation\Validator\Identical;
use Registro\Models\Manufacturer;

class ManufacturerForm extends Form {

    public function initialize( Manufacturer $manufacturer )
    {
        $manufacturer_id = new Hidden( 'manufacturer_id' );
        $this->add( $manufacturer_id );
        
        $manufacturer_name = new Text( 'manufacturer_name' );
        $this->add( $manufacturer_name );

        $this->add( new Submit( 'save' ) );
       
    }
}
