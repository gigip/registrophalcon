<?php

namespace Registro\Forms;

use Phalcon\Forms\Form;
use Phalcon\Forms\Element\Text;
use Phalcon\Forms\Element\Password;
use Phalcon\Forms\Element\Submit;
use Phalcon\Forms\Element\Check;
use Phalcon\Forms\Element\Hidden;
use Phalcon\Validation\Validator\PresenceOf;
use Phalcon\Validation\Validator\Email;
use Phalcon\Validation\Validator\Identical;

class LoginForm extends Form {

    public function initialize()
    {
        // Email
        $email = new Text( 'user_email' );
        $email->setLabel( $this->view->t->_( USER_EMAIL ) );
        $email->addValidators( [
            new PresenceOf( [
                'message' => $this->view->t->_( REQUIRED, ["field" => $email->getLabel() ] )
                    ] ),
            new Email( [
                'message' => $this->view->t->_( INVALID_DATA, ["field" => $email->getLabel() ] )
                    ] )
        ] );

        $this->add( $email );

        // Password
        $password = new Password( 'user_password' );
        $password->setLabel( $this->view->t->_( USER_PASSWORD ) );
        $password->addValidator( new PresenceOf( [
            'message' => $this->view->t->_( REQUIRED, ["field" => $password->getLabel() ] )
        ] ) );

        $password->clear();

        $this->add( $password );

        // Remember
        $remember = new Check( 'remember', [
            'value' => 'yes'
        ] );

        $remember->setLabel( $this->view->t->_( LOGIN_REMEMBER_ME ) );

        $this->add( $remember );

        // CSRF
        $csrf = new Hidden( 'csrf' );

        $csrf->addValidator( new Identical( [
            'value' => $this->security->getSessionToken(),
            'message' => 'CSRF validation failed'
        ] ) );

        $csrf->clear();

        $this->add( $csrf );

        $this->add( new Submit( $this->view->t->_('LOGIN') ) );
    }

}
