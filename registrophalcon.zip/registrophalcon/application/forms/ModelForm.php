<?php

namespace Registro\Forms;

use Phalcon\Forms\Form;
use Registro\Forms\Elements\Text;
use Phalcon\Forms\Element\Password;
use Registro\Forms\Elements\Submit;
use Phalcon\Forms\Element\Check;
use Phalcon\Forms\Element\Hidden;
use Phalcon\Validation\Validator\PresenceOf;
use Phalcon\Validation\Validator\Email;
use Phalcon\Validation\Validator\Identical;
use Registro\Models\Manufacturers;

class ModelForm extends Form {

    public function initialize()
    {
        $model_manufacturer_id = new Hidden( 'model_manufacturer_id' );
        $this->add( $model_manufacturer_id );

        $model_manufacturer_name = new Text( 'model_manufacturer_name' );
        $this->add( $model_manufacturer_name );

        $model_id = new Hidden( 'model_id' );
        $this->add( $model_id );
        
        $model_name = new Text( 'model_fullname' );
        $this->add( $model_name );

        $this->add( new Submit( 'save' ) );
    }

}
