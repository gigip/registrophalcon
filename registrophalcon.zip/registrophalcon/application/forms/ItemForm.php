<?php

namespace Registro\Forms;

use Phalcon\Forms\Form;
use Registro\Forms\Elements\Text;
use Registro\Forms\Elements\Select;
use Registro\Forms\Elements\Date;
use Phalcon\Forms\Element\Submit;
use Phalcon\Forms\Element\Hidden;
use Phalcon\Validation\Validator\PresenceOf;
use Registro\Models\Item;
use Registro\Models\ItemCategory;

class ItemForm extends Form {

    public function initialize( Item $item, array $options )
    {
        switch( $options['step'] ){
            case 1:
                $item_category_id = new Select(
                        "item_category_id", ItemCategory::find(), [
                            'useEmpty' => true,
                            'emptyText' => $this->view->t->_( 'select_category' ),
                            'using' => [
                                'category_id',
                                'category_name',
                            ]
                        ]
                );
                $this->add( $item_category_id );

                $item_manufacturer_id = new Select( 'item_manufacturer_id',        
                                                    [
                                                        $item->model->manufacturer->manufacturer_id => $item->model->manufacturer->manufacturer_name
                                                    ] );
                $item_manufacturer_id->addValidator( new PresenceOf( [
                    'message' => $this->view->t->_( REQUIRED, ["field" => 'item_manufacturer_id' ] )
                        ] )
                );

                $this->add( $item_manufacturer_id );

//                $item_manufacturer_name = new Select( 'item_manufacturer_name', [ ] );
//                $this->add( $item_manufacturer_name );

                $item_model_id = new Select( 'item_model_id', 
                                                    [
                                                        $item->model->model_id => $item->model->model_fullname
                                                    ]);
                $item_model_id->addValidator( new PresenceOf( [
                    'message' => $this->view->t->_( REQUIRED, ["field" => 'item_model_fullname' ] )
                        ] )
                );
                $this->add( $item_model_id );

                //$item_manufacturer_id->addOption(['a' => 'seleziona']);
                //\Phalcon\Tag::setDefault('item_name', 'nome');
                //               $this->add($item_manufacturer_id);


                break;

            case 2:
                $item_purchase_date = new Date( 'item_purchase_date' );
                $this->add( $item_purchase_date );

                $item_serial_code = new Text( 'item_serial_code' );
                $this->add( $item_serial_code );
                break;
        }
        $this->add( new Submit( $this->view->t->_( 'proceed' ) ) );
    }

}
