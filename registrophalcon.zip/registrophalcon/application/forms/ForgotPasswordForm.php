<?php

namespace Registro\Forms;

use Phalcon\Forms\Form;
use Phalcon\Forms\Element\Text;
use Phalcon\Forms\Element\Submit;
use Phalcon\Validation\Validator\PresenceOf;
use Phalcon\Validation\Validator\Email;

class ForgotPasswordForm extends Form {

    public function initialize()
    {
        $email = new Text( 'user_email' );
        $email->setLabel( $this->view->t->_( USER_EMAIL ) );
        $email->addValidators( [
            new PresenceOf( [
                'message' => $this->view->t->_( REQUIRED, ["field" => $email->getLabel() ] )
                    ] ),
            new Email( [
                'message' => $this->view->t->_( INVALID_DATA, ["field" => $email->getLabel() ] )
                    ] )
        ] );

        $this->add( $email );

        $this->add( new Submit( $this->view->t->_( SEND ) ) );
    }

}
