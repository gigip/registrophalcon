<?php

namespace Registro\Forms;

use Phalcon\Forms\Form;
use Phalcon\Forms\Element\Text;
use Phalcon\Forms\Element\Email;
use Phalcon\Forms\Element\Hidden;
use Phalcon\Forms\Element\Password;
use Phalcon\Forms\Element\Submit;
use Phalcon\Forms\Element\Check;
use Phalcon\Validation\Validator\PresenceOf;
use Phalcon\Validation\Validator\Email as EmailValidator;
use Phalcon\Validation\Validator\Identical;
use Phalcon\Validation\Validator\StringLength;
use Phalcon\Validation\Validator\Confirmation;
use Phalcon\Validation\Validator\Regex;
use Phalcon\Validation\Validator\Uniqueness;
use Phalcon\Validation\Validator\Alnum;
class SignUpForm extends Form {

    public function initialize( $entity = null, $options = null )
    {
        $user_username = new Text( 'user_username' );

        $user_username->setLabel( $this->view->t->_( USER_USERNAME ) );
        $user_username->addValidators( [
            new PresenceOf( [
                'message' => $this->view->t->_( REQUIRED, ["field" => $user_username->getLabel() ] )
                    ] ),
            new Alnum([
                'message' => $this->view->t->_( ALNUM_ONLY, ["field" => $user_username->getLabel() ] )
                    ] )
        ] );

        $this->add( $user_username );

        $user_firstname = new Text( 'user_firstname' );
        $user_firstname->setLabel( $this->view->t->_( USER_FIRSTNAME ) );
        $user_firstname->addValidators( [
            new PresenceOf( [
                'message' => $this->view->t->_( REQUIRED, ["field" => $user_firstname->getLabel() ] )
                    ] ),
            new Regex( [
                'pattern' => '/^[a-zA-Zàáèéìíòóùú0-9\' ]+$/',
                'message' => $this->view->t->_( INVALID_DATA, ["field" => $user_firstname->getLabel() ] )
            ] )
        ] );

        $this->add( $user_firstname );

        $user_lastname = new Text( 'user_lastname' );
        $user_lastname->setLabel( $this->view->t->_( USER_LASTNAME ) );
        $user_lastname->addValidators( [
            new PresenceOf( [
                'message' => $this->view->t->_( REQUIRED, ["field" => $user_lastname->getLabel() ] )
                    ] ),
            new Regex( [
                'pattern' => '/^[a-zA-Zàáèéìíòóùú0-9\' ]+$/',
                'message' => $this->view->t->_( INVALID_DATA, ["field" => $user_lastname->getLabel() ] )
            ] )            
        ] );

        $this->add( $user_lastname );

        // Email
        $user_email = new Email( 'user_email' );
        $user_email->setLabel( $this->view->t->_( USER_EMAIL ) );
        $user_email->addValidators( [
            new PresenceOf( [
                'message' => $this->view->t->_( REQUIRED, ["field" => $user_email->getLabel() ] )
                    ] ),
            new EmailValidator( [
                'message' => $this->view->t->_( INVALID_DATA, ["field" => $user_email->getLabel() ] )
                    ] ), 
            new Uniqueness([
                'message' => $this->view->t->_( SIGNUP_EMAIL_IN_USE, ["field" => $user_email->getLabel() ] ),
                'model' => $entity
            ])
        ] );

        $this->add( $user_email );

        // Password
        $user_password = new Password( 'user_password' );
        $user_password->setLabel( $this->view->t->_( USER_PASSWORD ) );

        $user_password->addValidators( [
            new PresenceOf( [
                'message' => $this->view->t->_( REQUIRED, ["field" => $user_password->getLabel() ] )
                    ] ),
            new StringLength( [
                'min' => 8,
                'messageMinimum' => $this->view->t->_( SIGNUP_PASSWORD_TOO_SHORT, ["field" => $user_password->getLabel() ] )
                    ] )
        ] );

        $this->add( $user_password );

        // Confirm Password
        $confirmPassword = new Password( 'confirmPassword' );
        $confirmPassword->setLabel( $this->view->t->_( SIGNUP_CONFIRM_PASSWORD ) );

        $confirmPassword->addValidators( [
            new PresenceOf( [
                'message' => $this->view->t->_( REQUIRED, ["field" => $confirmPassword->getLabel() ] )
                    ] ),
            new Confirmation( [
                'message' => $this->view->t->_( SIGNUP_PASSWORD_NO_MATCH, ["field" => $user_password->getLabel() ] ),
                'with' => 'confirmPassword'
                    ] )
        ] );

        $this->add( $confirmPassword );

        // Remember
        $terms = new Check( 'terms', [
            'value' => 'yes'
                ] );

        $terms->setLabel( $this->view->t->_( SIGNUP_ACCEPT_TERMS ) );

        $terms->addValidator( new Identical( [
            'value' => 'yes',
            'message' => $this->view->t->_( SIGNUP_TERMS_MUST_BE_ACCEPTED, ["field" => $terms->getLabel() ] )
        ] ) );

        $this->add( $terms );

        // CSRF
                $this->view->setVars([
            'tokenKey' => $this->security->getTokenKey(),
            'token' => $this->security->getToken()
        ]);// 
        $csrf = new Hidden( $this->security->getTokenKey() );

        $csrf->addValidator( new Identical( [
            'value' => $this->security->getSessionToken(),
            'message' => 'CSRF validation failed'
        ] ) );

        $csrf->clear();

        $this->add( $csrf );

        // Sign Up
        $signup = new Submit( $this->view->t->_( SIGNUP ) );
        $this->add( $signup );
    }

    /**
     * Prints messages for a specific element
     */
//    public function messages( $name )
//    {
//        if( $this->hasMessagesFor( $name ) )
//        {
//            foreach( $this->getMessagesFor( $name ) as $message ){
//                $this->flash->error( $message );
//            }
//        }
//    }

}
